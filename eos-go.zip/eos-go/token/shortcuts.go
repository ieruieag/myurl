package token

import eos "github.com/eoscanada/eos-go"

var AN = eos.AN
var PN = eos.PN
var ActN = eos.ActN
