#include <dz.hpp>
#include <array>

void getCardValueBystr(string str, QP_Value_Cards &cards) {
	std::vector<std::string> list = splitSV(str, "|");
	for (auto cardStr : list) {
		cards.push_back(std::atoi(cardStr.data()));
	}
}

dz::dz(name receiver, name code, datastream<const char*> ds)
: contract(receiver, code, ds), 
  _globalState_table(receiver, receiver.value),
  _games_table(receiver, receiver.value),
  _gamesInfo_table(receiver, receiver.value),
  _betInfo_table(receiver, receiver.value),
  _globalVars_table(receiver, receiver.value),
  _gameLog_table(receiver, receiver.value)
{}

ACTION dz::clearalltable() {
  require_auth(get_self());
  clearTable(_globalState_table);
  clearTable(_games_table);
  clearTable(_gamesInfo_table);
  clearTable(_globalVars_table);
  clearTable(_gameLog_table);
  auto g_itr = _betInfo_table.begin();
  while (g_itr != _betInfo_table.end()) {
    g_itr = _betInfo_table.erase(g_itr);
  }
}

ACTION dz::startgame(){
  require_auth(get_self());
  auto gitr = getGItr();
  auto game_itr = _games_table.find(gitr->cur_game_id);
  if (game_itr != _games_table.end() && game_itr->state < gameState::B_DEAL){
    //流局
    _games_table.modify(game_itr, get_self(), [&](auto& game) {
        game.state = gameState::DRAW;
        game.winner = winState::W_DRAW;
    });
    //find bets in this game
    auto game_index = _betInfo_table.get_index<name("bygameid")>();
    auto bet_itr = game_index.find(game_itr->id);
    auto betState = betState::WAIT_SETTLEMENT;
    while(bet_itr != game_index.end() && bet_itr->game_id == game_itr->id){
      if(bet_itr->state == betState::BS_BETTING){
        game_index.modify(bet_itr,get_self(), [&](auto& bet) {
          bet.state = betState::WAIT_SETTLEMENT;
        });
      }
      bet_itr++;
    }
    settelmentNext(0);
    string data;
    data += "{";
    pushJsonEx(data,"event_id","gameCancel");
    pushJson(data,"game_id",gitr->cur_game_id);
    pushJson(data,"state",gameState::DRAW);
    _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
        gameLog.id = getNewLogsIndex();
        gameLog.data = data;
    });
  }
}

//////////////////////////start/////////////////
ACTION dz::startbet(uint64_t block_index, string seed_sign){
    require_auth(get_self());
    auto gameid = 0;
    asset zero;
    zero.symbol = symbol(USE_SYMBOL,4);
    string data;
    data += "{";
    pushJsonEx(data,"event_id","gameStart");
    auto stop_time = (current_time_point() + seconds(getTimePreflop())).sec_since_epoch();

    _games_table.emplace(get_self(), [&](auto& game) {
        game.id = _games_table.available_primary_key();
        game.state = gameState::PRE_FLOP;
        game.created_at = get_current_time();
        game.bi_player = block_index;
        gameid = game.id;
    });
    _gamesInfo_table.emplace(get_self(), [&](auto& info) {
        info.game_id = gameid;
        info.sign_player = seed_sign;
        info.stop_at_player = stop_time;

        pushJson(data,"game_id",gameid);
        pushJson(data,"state",1);
        pushJson(data,"stop_at",info.stop_at_player);
    });
    auto gitr = getGItr();
    _globalVars_table.modify(gitr,get_self(), [&](auto& gvar) {
        gvar.cur_game_id = gameid;
        gvar.next_block_index = block_index;
        gvar.next_seed_sign = seed_sign;
        gvar.next_stop_time = stop_time;
        gvar.total_ante = zero;
        gvar.total_blind = zero;
        gvar.total_color = zero;
        gvar.total_raise = zero;
        gvar.game_balance = getUserBalance(get_self());
        gvar.limit_ante = asset(getLimitAnte(),symbol(USE_SYMBOL,4));
        gvar.limit_blind = asset(getLimitBlind(),symbol(USE_SYMBOL,4));
        gvar.limit_color = asset(getLimitColor(),symbol(USE_SYMBOL,4));
        gvar.limit_raise = asset(getLimitRaise(),symbol(USE_SYMBOL,4));

        pushJson(data,"next_index",block_index);
        pushJsonEx(data,"next_sign",seed_sign);
        pushJson(data,"limit_ante",gvar.limit_ante.amount);
        pushJson(data,"limit_blind",gvar.limit_blind.amount);
        pushJson(data,"limit_color",gvar.limit_color.amount);
        pushJson(data,"limit_raise",gvar.limit_raise.amount,false);
    });
    //清空之前的log
    clearTable(_gameLog_table);
    _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
        gameLog.id = getNewLogsIndex();
        gameLog.data = data;
    });

    deleteOldGameStatus();
}

bool dz::analyzeMemo(std::string &memo, betInfo& info,asset& total) {
    std::vector<std::string> infos = splitSV(memo, "|");
    if(infos.size() != 9){
      return false;
    }
    info.action     = infos[0];
    info.game_id    = std::stoll(infos[1].data());
    info.player     = name(infos[2]);
    info.bet_amount = asset(floatStrToInt(infos[3].data()),total.symbol);
    info.bet_ante  = asset(floatStrToInt(infos[4].data()),total.symbol);
    info.bet_blind    = asset(floatStrToInt(infos[5].data()),total.symbol);
    info.bet_color = asset(floatStrToInt(infos[6].data()),total.symbol);
    info.bet_raise = asset(floatStrToInt(infos[7].data()),total.symbol);
    info.sign = infos[8];

    eosio::check(total == info.bet_ante + info.bet_blind + info.bet_color + info.bet_raise,
    "bet amount not match " + total.to_string() + "!= " + (info.bet_ante + info.bet_blind + info.bet_color + info.bet_raise).to_string());
    eosio::check(info.bet_ante.amount >= 0,"amount is wrong = " + to_string(info.bet_ante.amount));
    eosio::check(info.bet_blind.amount >= 0,"amount is wrong = " + to_string(info.bet_blind.amount));
    eosio::check(info.bet_color.amount >= 0,"amount is wrong = " + to_string(info.bet_color.amount));
    eosio::check(info.bet_raise.amount >= 0,"amount is wrong = " + to_string(info.bet_raise.amount));
    return true;
}

void dz::deposit(name from, name to, eosio::asset quantity, std::string memo)
{
  require_auth(from);
  // eosio::check(get_self() == to, "wrong deposit");
  if(get_self() != to){
    return;
  }

  eosio::check(quantity.symbol.code().to_string()==USE_SYMBOL,"only support eos token not "+quantity.symbol.code().to_string());

  betInfo info;
  if(!analyzeMemo(memo,info,quantity)){
    return;
  }
  //check game is betting
  auto game_itr = _games_table.require_find(info.game_id,"can't find this game");
  eosio::check(gameState::PAUSE < game_itr->state && game_itr->state < gameState::B_DEAL, "game is not in betting =" + to_string(game_itr->state));

  auto gitr = getGItr();
    // check sign
  eosio::check(info.sign==gitr->next_seed_sign, "wrong sign");
  eosio::check(gitr->next_stop_time>get_current_time(), "is stop time");
  if(game_itr->state == gameState::PRE_FLOP){
    eosio::check(info.bet_raise.amount == 0,"PRE_FLOP can't raise");
  }else{
    eosio::check(info.bet_ante.amount == 0,"only raise in " + to_string(game_itr->state));
    eosio::check(info.bet_blind.amount == 0,"only raise in " + to_string(game_itr->state));
    eosio::check(info.bet_color.amount == 0,"only raise in " + to_string(game_itr->state));
  }

  _globalVars_table.modify(gitr,get_self(), [&](auto& gvar) {
    gvar.total_ante  += info.bet_ante;
    gvar.total_blind += info.bet_blind;
    gvar.total_color += info.bet_color;
    gvar.total_raise += info.bet_raise;
    gvar.game_balance = getUserBalance(get_self());
    eosio::check(gvar.total_ante <= gitr->limit_ante, "exceeded max ante");
    eosio::check(gvar.total_blind <= gitr->limit_blind, "exceeded max blind");
    eosio::check(gvar.total_color <= gitr->limit_color, "exceeded max color");
    eosio::check(gvar.total_raise <= gitr->limit_raise, "exceeded max raise");
  });

  //write log
  string data;
  data += "{";
  pushJsonEx(data,"event_id","newBet");
  pushJson(data,"game_id",info.game_id);
  pushJsonEx(data,"player",from.to_string());
  pushJsonEx(data,"ante_amt",info.bet_ante.to_string());
  pushJsonEx(data,"blind_amt",info.bet_blind.to_string());
  pushJsonEx(data,"color_amt",info.bet_color.to_string());
  pushJsonEx(data,"raise_amt",info.bet_raise.to_string());
  pushJson(data,"state",game_itr->state);
  std::string tx_id;
  get_transaction_tx(tx_id);
  pushJsonEx(data,"tx_id",tx_id,false);
  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    gameLog.id = getNewLogsIndex();
    gameLog.data = data;
  });
  //find player
  auto player_index = _betInfo_table.get_index<name("byplayer")>();
  auto bet_itr = player_index.find(from.value);
  auto finded = false;
  //find gameid
  while(bet_itr != player_index.end() && bet_itr->player.value == from.value){
    if(bet_itr->game_id == info.game_id ){
      finded = true;
      break;
    }
    bet_itr++;
  }
  
  if (finded) {
    eosio::check(bet_itr->state == betState::BS_BETTING,"state not betting!");
    player_index.modify(bet_itr,get_self(), [&](auto& bet) {
      bet.ante_amt += info.bet_ante;
      bet.blind_amt += info.bet_blind;
      bet.color_amt += info.bet_color;
      bet.raise_amt += info.bet_raise;
      bet.created_at = get_current_time();
      bet.tx_id = get_transaction_tx();
    });
  }else{
    _betInfo_table.emplace(get_self(), [&](auto& bet) {
      bet.id = _betInfo_table.available_primary_key();
      bet.player = from;
      bet.game_id = info.game_id;
      bet.ante_amt  = info.bet_ante;
      bet.blind_amt = info.bet_blind;
      bet.color_amt = info.bet_color;
      bet.raise_amt = info.bet_raise;
      bet.created_at = get_current_time();
      bet.tx_id = get_transaction_tx();
      bet.state = betState::BS_BETTING;
    });
  }

  bet_action act{ get_self(), {get_self(), "active"_n}};
  act.send(info.game_id,from,info.bet_ante,info.bet_blind,info.bet_color,info.bet_raise,game_itr->state,info.sign);
}

void dz::commonFlopCard(string &block_hash,string &seed,uint64_t next_block_index, string &next_seed_sign,gameState newState,int cardNum,int64_t time){
    require_auth(get_self());
    auto gitr = getGItr();
    auto gameItr = _games_table.require_find(gitr->cur_game_id,"can't find this game");
    eosio::check(gameItr->state == newState - 1 ,"state is wong need = " + to_string(newState - 1) + " now is " + to_string(gameItr->state));
    auto infoItr = _gamesInfo_table.require_find(gitr->cur_game_id,"can't find this gameinfo");

    string code;
    getCardsCode(seed,block_hash,code);
    size_t begin = code.size() - 1;
    QP_Value_Cards allcards;
    QP_Value_Cards existedCards;
    if(gameItr->poker_player != ""){
      getCardValueBystr(gameItr->poker_player,existedCards);
    }
    if(gameItr->poker_flop != ""){
      getCardValueBystr(gameItr->poker_flop,existedCards);
    }
    if(gameItr->poker_turn != ""){
      getCardValueBystr(gameItr->poker_turn,existedCards);
    }
    if(gameItr->poker_river != ""){
      getCardValueBystr(gameItr->poker_river,existedCards);
    }if(gameItr->poker_banker != ""){
      getCardValueBystr(gameItr->poker_banker,existedCards);
    }
    getMultiCard(code, begin, allcards,existedCards, cardNum);
    eosio::check(allcards.size() == cardNum,code + " can't get card num = " + to_string(cardNum));
    auto stop_time = (current_time_point() + seconds(time)).sec_since_epoch();

    string data;
    data += "{";
    pushJsonEx(data,"event_id","gameDeal");
    pushJson(data,"game_id",gitr->cur_game_id);
    pushJson(data,"state",newState);
    pushJsonEx(data,"code",code);
    pushJsonEx(data,"block_hash",block_hash);
    pushJsonEx(data,"seed",seed);

    _games_table.modify(gameItr, get_self(), [&](auto& game) {
        game.state = newState;
        if(newState == gameState::P_DEAL){
          game.bi_flop = next_block_index;
          game.code_player = code;
          getCardStr(game.poker_player,allcards);
          pushJsonEx(data,"card",game.poker_player);
        }else if(newState == gameState::FLOP_ROUND){
          game.bi_turn = next_block_index;
          game.code_flop = code;
          getCardStr(game.poker_flop,allcards);
          pushJsonEx(data,"card",game.poker_flop);
        }else if(newState == gameState::TURN_ROUND){
          game.bi_river = next_block_index;
          game.code_turn = code;
          getCardStr(game.poker_turn,allcards);
          pushJsonEx(data,"card",game.poker_turn);
        }else if(newState == gameState::RIVER_ROUND){
          game.bi_banker = next_block_index;
          game.code_river = code;
          getCardStr(game.poker_river,allcards);
          pushJsonEx(data,"card",game.poker_river);
        }else if(newState == gameState::B_DEAL){
          game.code_banker = code;
          getCardStr(game.poker_banker,allcards);
          pushJsonEx(data,"card",game.poker_banker);
        }
    });
    pushJson(data,"stop_at",stop_time);
    pushJson(data,"next_index",next_block_index);
    pushJsonEx(data,"next_sign",next_seed_sign,false);
    _gamesInfo_table.modify(infoItr, get_self(), [&](auto& info) {
      if(newState == gameState::P_DEAL){
        info.seed_player = seed;
        info.bh_player = block_hash;
        info.tx_player = get_transaction_tx();
        info.stop_at_flop = stop_time;
        info.sign_flop = next_seed_sign;
      } else if(newState == gameState::FLOP_ROUND){
        info.seed_flop = seed;
        info.bh_flop = block_hash;
        info.tx_flop = get_transaction_tx();
        info.stop_at_turn = stop_time;
        info.sign_turn = next_seed_sign;
      } else if(newState == gameState::TURN_ROUND){
        info.seed_turn = seed;
        info.bh_turn = block_hash;
        info.tx_turn = get_transaction_tx();
        info.stop_at_river = stop_time;
        info.sign_river = next_seed_sign;
      } else if(newState == gameState::RIVER_ROUND){
        info.seed_river = seed;
        info.bh_river = block_hash;
        info.tx_river = get_transaction_tx();
        info.stop_at_river = stop_time;
        info.sign_banker = next_seed_sign;
      } else if(newState == gameState::B_DEAL){
        info.seed_banker = seed;
        info.bh_banker = block_hash;
        info.tx_banker = get_transaction_tx();
      }
    });
    _globalVars_table.modify(gitr,get_self(), [&](auto& gvar) {
        gvar.next_block_index = next_block_index;
        gvar.next_seed_sign = next_seed_sign;
        gvar.next_stop_time = stop_time;
    });
    _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
        gameLog.id = getNewLogsIndex();
        gameLog.data = data;
    });
}

ACTION dz::dealplayer(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign){
  commonFlopCard(block_hash,seed,next_block_index,next_seed_sign,
  gameState::P_DEAL,2, getTimePDeal());
}

ACTION dz::dealflop3(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign){
  commonFlopCard(block_hash,seed,next_block_index,next_seed_sign,
  gameState::FLOP_ROUND,3, getTimeFlop());
}

ACTION dz::dealturn(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign){
  commonFlopCard(block_hash,seed,next_block_index,next_seed_sign,
  gameState::TURN_ROUND,1, getTimeTurn());
}

ACTION dz::dealriver(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign){
  commonFlopCard(block_hash,seed,next_block_index,next_seed_sign,
  gameState::RIVER_ROUND,1, getTimeRiver());
}

ACTION dz::dealbanker(string block_hash,string seed){
  string tmp;
  commonFlopCard(block_hash,seed,0,tmp,
  gameState::B_DEAL,2, 0);
  finish();
  settelmentNext(0);
}

template<size_t _Size>
void valueCardToCard(QP_Value_Cards& valueCards, std::array<QPCard, _Size>& cards){
  eosio::check(valueCards.size() == _Size,"to card size wrong " + to_string(valueCards.size()) + " != " + to_string(_Size));
  for(int i = 0; i<_Size; i++){
    cards[i].reset(valueCards[i]);
  }
}

void getAllCards(std::array<QPCard, 2>& handCards,std::array<QPCard, 5>& publicCards,QP_Cards &res){
  for(int i=0; i<2; i++){
    res.push_back(&handCards[i]);
  }
  for(int i=0; i<5; i++){
    res.push_back(&publicCards[i]);
  }
  // for(auto c : res){
  //   print(to_string(c->m_cardRawValue));
  //   print("*");
  // }
  // print("*");
}

void dz::finish(){
  auto gitr = getGItr();
  auto gameItr = _games_table.require_find(gitr->cur_game_id,"can't find this game");
  eosio::check(gameItr->state == gameState::B_DEAL ,"state is wong need B_DEAL, now is " + to_string(gameItr->state));
  auto infoItr = _gamesInfo_table.require_find(gitr->cur_game_id,"can't find this gameinfo");

  string data;
  data += "{";
  pushJsonEx(data,"event_id","gameResult");
  pushJson(data,"game_id",gitr->cur_game_id);
  pushJson(data,"state",gameState::B_DEAL);

  //获得结果
  QP_Value_Cards playerValueCards;
  QP_Value_Cards bankerValueCards;
  QP_Value_Cards publicValueCards;
  //QPCard所有实体，后面需要用到指针
  std::array<QPCard,2> playerCardOrg;
  std::array<QPCard,2> bankerCardOrg;
  std::array<QPCard,5> publicCardOrg;
  QP_Cards playerCards;
  QP_Cards bankerCards;
  QPCardsClass playerCardsClass;
  QPCardsClass bankerCardsClass;
  // QPCard *pCard = 0;

  getCardValueBystr(gameItr->poker_player,playerValueCards);
  getCardValueBystr(gameItr->poker_flop,publicValueCards);
  getCardValueBystr(gameItr->poker_turn,publicValueCards);
  getCardValueBystr(gameItr->poker_river,publicValueCards);
  getCardValueBystr(gameItr->poker_banker,bankerValueCards);
  valueCardToCard(playerValueCards,playerCardOrg);
  valueCardToCard(bankerValueCards,bankerCardOrg);
  valueCardToCard(publicValueCards,publicCardOrg);

  //player的结果
  getAllCards(playerCardOrg,publicCardOrg,playerCards);
  dzLogic::GetCardResults(playerCardsClass,playerCards);
  //banker的结果
  getAllCards(bankerCardOrg,publicCardOrg,bankerCards);
  dzLogic::GetCardResults(bankerCardsClass,bankerCards);
  
  //获取结果
  auto ret = QPCardsClass::compair(playerCardsClass,bankerCardsClass);
  uint32_t winner;
  uint32_t win_card_type;
  switch(ret){
    case EQUAL_TO_LESS_THAN:
      winner = 1; //庄
      win_card_type = bankerCardsClass.cardsType;
      break;
    case EQUAL_TO_MORE_THAN:
      winner = 2; //闲
      win_card_type = playerCardsClass.cardsType;
      break;
    case EQUAL_TO_EQUAL:
      winner = 3; //和
      win_card_type = bankerCardsClass.cardsType;
      break;
  }
  _games_table.modify(gameItr, get_self(), [&](auto& game){
    //  game.state = gameState::FINISH;
     playerCardsClass.getCardStr(game.player);
     bankerCardsClass.getCardStr(game.banker);
     game.winner = winner;
     game.win_card_type = win_card_type;
     pushJsonEx(data,"player",game.player);
     pushJsonEx(data,"banker",game.banker);
     pushJson(data,"winner",winner);
     pushJson(data,"win_card_type",win_card_type,false);
  });

  //find bets in this game
  auto game_index = _betInfo_table.get_index<name("bygameid")>();
  auto bet_itr = game_index.find(gameItr->id);
  auto betState = betState::WAIT_SETTLEMENT;
  while(bet_itr != game_index.end() && bet_itr->game_id == gameItr->id){
    if(bet_itr->state == betState::BS_BETTING){
      //必须加注
      betState = betState::WAIT_SETTLEMENT;
      if(bet_itr->raise_amt.amount <= 0 || bet_itr->ante_amt.amount <=0){
        betState = betState::BS_FOLD;
      }
      game_index.modify(bet_itr,get_self(), [&](auto& bet) {
        bet.state = betState;
      });
    }
    bet_itr++;
  }

  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
      gameLog.id = getNewLogsIndex();
      gameLog.data = data;
  });

  // eosio::check(1==2,"11");
  record_action act{ get_self(), {get_self(), "active"_n}};
  act.send(*gameItr,*infoItr,getCardStrPork(gameItr->poker_player),getCardStrPork(gameItr->poker_flop),getCardStrPork(gameItr->poker_turn),getCardStrPork(gameItr->poker_river),getCardStrPork(gameItr->poker_banker),getCardStrPork(gameItr->player,true),getCardStrPork(gameItr->banker,true),winnerStr[winner-1]);
}

void dz::settelmentNext(uint32_t count)
{
  eosio::transaction txn{};
  txn.actions.emplace_back(
      eosio::permission_level(get_self(), "active"_n),
      get_self(),
      "settlement"_n,
      std::make_tuple(getSizepayout(),count + 1));
  txn.delay_sec = 1;
  txn.send(getSetIndex(), get_self());

  // settlement_action act{ get_self(), {get_self(), "active"_n}};
  // act.send(5,count + 1);
}

ACTION dz::fold(name player,uint64_t game_id,string sign){
  require_auth(player);
  auto gitr = getGItr();

  eosio::check(sign == gitr->next_seed_sign,"fold wrong sign!");
  //find player
  auto player_index = _betInfo_table.get_index<name("byplayer")>();
  auto bet_itr = player_index.find(player.value);
  auto finded = false;
  //find gameid
  while(bet_itr != player_index.end() && bet_itr->player.value == player.value){
    // print(to_string(bet_itr->game_id));
    // print("|");
    if(bet_itr->game_id == game_id ){
      finded = true;
      break;
    }
    bet_itr++;
  }
  // print("--");
  // print(to_string(finded));
  if (finded) {
    player_index.modify(bet_itr,get_self(), [&](auto& bet) {
      bet.state = betState::BS_FOLD;
    });
  }

  // auto gameItr = _games_table.require_find(game_id,"can't find this game");
  // _games_table.modify(gameItr, get_self(), [&](auto& game) {
  //   game.state = gameState::FINISH;
  // });5
}

bool dz::isInSettlement(int32_t state){
  return state == gameState::B_DEAL || state == gameState::DRAW;
}

void dz::finishTheGameSettlement(games_table::const_iterator game_itr){
  if(game_itr->state == gameState::B_DEAL){
    _games_table.modify(game_itr,get_self(), [&](auto& gameStatus) {
      gameStatus.state = gameState::FINISH;
    });
    deleteBets(game_itr->id);
  }
    
}

void dz::finishLog(string_view winners,uint64_t id){
  if (winners != ""){
    string data = "{";
    pushJsonEx(data,"event_id","gameSettlement");
    pushJson(data,"game_id",id);
    pushJson(data,"state",gameState::FINISH);
    pushJsonEx(data,"winners",winners,false);
    _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
      gameLog.id = getNewLogsIndex();
      gameLog.data = data;
    });
  }
}

void dz::calculateAndPayment(games_table::const_iterator game_itr,betInfo_table::const_iterator bet_itr,string &winners){
    asset winCount;
    string memo;
    auto bet_state = betState::WAIT_SETTLEMENT;
    winCount.symbol = symbol(USE_SYMBOL,4);
    asset ante_win = winCount;
    asset blind_win = winCount;
    asset color_win = winCount;
    asset raise_win = winCount;
    string winstr = winnerStr[game_itr->winner-1];
    if(bet_itr->state == betState::BS_FOLD){
      memo = "fold";
      winstr = "fold";
    }
    else if(game_itr->state == gameState::DRAW){
      //流局返还
      winCount = bet_itr->ante_amt + bet_itr->blind_amt + bet_itr->color_amt + bet_itr->raise_amt;
      memo = "draw";
      bet_state = betState::BS_DRAW;
    }
    else{
      bet_state = betState::BS_FINISH;
      //彩注
      if(bet_itr->color_amt.amount > 0 && game_itr->win_card_type > dzLogic::DZ_CARD_TYPE_TWO_PAIR){
        color_win = bet_itr->color_amt * colorRate[game_itr->win_card_type-1] / RATE_DECIMAL;
        winCount += color_win;
        // winCount += bet_itr->color_amt * colorRate[game_itr->win_card_type-1] / RATE_DECIMAL;
      }

      if (game_itr->winner == winState::W_BANKER && game_itr->win_card_type == dzLogic::emCardType::DZ_CARD_TYPE_HIGHCARD && bet_itr->state != betState::BS_FOLD){
        //庄家散牌赢(非弃牌)，退底注
        ante_win = bet_itr->ante_amt;
        winCount += ante_win;
        // winCount += bet_itr->ante_amt;
      } 
      else if (game_itr->winner == winState::W_PLAYER){
        //底注
          ante_win = bet_itr->ante_amt * anteRate / RATE_DECIMAL;
          winCount += ante_win;
          // winCount += bet_itr->ante_amt * anteRate / RATE_DECIMAL;
          //盲注
          blind_win = bet_itr->blind_amt * blindRate[game_itr->win_card_type-1] / RATE_DECIMAL;
          winCount += blind_win;
          // winCount += bet_itr->blind_amt * blindRate[game_itr->win_card_type-1] / RATE_DECIMAL;
          //加注
          raise_win = bet_itr->raise_amt * raiseRate / RATE_DECIMAL;
          winCount += raise_win;
          // winCount += bet_itr->raise_amt * raiseRate / RATE_DECIMAL;
        
        memo = "You Win";

        if(winners.size()!=0){
          winners += "|";
        }
        winners += bet_itr->player.to_string();
        winners += "-";
        winners += winCount.to_string();
      }else if (game_itr->winner == winState::W_TIE){
        //退底注，盲注，加注
        ante_win = bet_itr->ante_amt;
        blind_win = bet_itr->blind_amt;
        raise_win = bet_itr->raise_amt;   

        winCount = ante_win + blind_win + raise_win;
        // winCount = bet_itr->ante_amt + bet_itr->blind_amt + bet_itr->raise_amt;
        memo = "Tie";
      }else{
        memo = "You Lose";
      }
    }

    if(winCount.amount > 0){
      action{
        permission_level{get_self(), "active"_n},
        "eosio.token"_n,
        "transfer"_n,
        std::make_tuple(get_self(), bet_itr->player, winCount,
        memo)
      }.send();
    }

    // state_index.modify(bet_itr,get_self(), [&](auto& bet) {
    //   bet.state = bet_state;
    //   bet.tx_id = get_transaction_tx();
    // });
    reveal_action act{ get_self(), {get_self(), "active"_n}};
    act.send(game_itr->id,getCardStrPork(game_itr->poker_player),getCardStrPork(game_itr->poker_flop),getCardStrPork(game_itr->poker_turn),getCardStrPork(game_itr->poker_river),getCardStrPork(game_itr->poker_banker),getCardStrPork(game_itr->player,true),getCardStrPork(game_itr->banker,true),winstr,bet_itr->player,bet_itr->ante_amt,bet_itr->blind_amt,bet_itr->color_amt,bet_itr->raise_amt,ante_win,blind_win,color_win,raise_win,winCount);
}

ACTION dz::settlement(uint32_t dispose_count,uint32_t count){
  require_auth(get_self());

  auto gitr = getGItr();
  //find bets in this game
  // auto state_index = _betInfo_table.get_index<name("bystate")>();
  // auto bet_itr = state_index.find(betState::WAIT_SETTLEMENT);
  auto bet_itr = _betInfo_table.begin();
  if (bet_itr == _betInfo_table.end()){
    //结束当前局
    auto game_itr = _games_table.find(gitr->cur_game_id);
    finishTheGameSettlement(game_itr);
    return;
  }

  auto num = 0;
  // string data;
  uint64_t settlementId = bet_itr->game_id;  //正在结算的gameid
  auto game_itr = _games_table.find(settlementId);
  string memo;
  string winners = "";
  // auto bet_state = betState::WAIT_SETTLEMENT;
  while (bet_itr != _betInfo_table.end() && num<dispose_count) {
    num++;
    if(settlementId != bet_itr->game_id){
      //开始新一个局号的结算了，说明上一局结算完成
      // if(game_itr->state == gameState::B_DEAL){
      //   _games_table.modify(game_itr,get_self(), [&](auto& gameStatus) {
      //     gameStatus.state = gameState::FINISH;
      //   });
      //   deleteBets(game_itr->id);
      // }
      finishTheGameSettlement(game_itr);
      finishLog(winners, game_itr->id);

      // data = "{";
      // pushJsonEx(data,"event_id","gameSettlement");
      // pushJson(data,"game_id",game_itr->id);
      // pushJsonEx(data,"winners",winners,false);
      // _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
      //   gameLog.id = getNewLogsIndex();
      //   gameLog.data = data;
      // });

      winners = "";
      settlementId = bet_itr->game_id;
      game_itr = _games_table.find(settlementId);
    }

    if(bet_itr->state != betState::WAIT_SETTLEMENT && bet_itr->state != betState::BS_FOLD){
      bet_itr++;
      continue;
    }
    
    if(game_itr != _games_table.end()){      
      if(!isInSettlement(game_itr->state)){
        bet_itr++;
        continue;
      }

      calculateAndPayment(game_itr,bet_itr,winners);
      
      // calculateAndPayment(game_itr,_betInfo_table.iterator_to(*bet_itr),winners);
      // print("calculateAndPayment end|");
      // asset winCount;
      // winCount.symbol = symbol(USE_SYMBOL,4);
      // asset ante_win = winCount;
      // if(game_itr->state == gameState::DRAW){
      //   //流局返还
      //   winCount = bet_itr->ante_amt + bet_itr->blind_amt + bet_itr->color_amt + bet_itr->raise_amt;
      //   memo = "draw";
      //   bet_state = betState::BS_DRAW;
      // }
      // else{
      //   bet_state = betState::BS_FINISH;
      //   //彩注
      //   if(bet_itr->color_amt.amount > 0 && game_itr->win_card_type > dzLogic::DZ_CARD_TYPE_TWO_PAIR){
      //     winCount += bet_itr->color_amt * colorRate[game_itr->win_card_type-1] / RATE_DECIMAL;
      //   }

      //   if (game_itr->winner == winState::W_BANKER && game_itr->win_card_type == dzLogic::emCardType::DZ_CARD_TYPE_HIGHCARD && bet_itr->state != betState::BS_FOLD){
      //     //庄家散牌赢(非弃牌)，退底注
      //     winCount += bet_itr->ante_amt;
      //   } 
      //   else if (game_itr->winner == winState::W_PLAYER){
      //     //底注
      //     winCount += bet_itr->ante_amt * anteRate / RATE_DECIMAL;
      //     //盲注
      //     winCount += bet_itr->blind_amt * blindRate[game_itr->win_card_type-1] / RATE_DECIMAL;
      //     // //加注
      //     winCount += bet_itr->raise_amt * raiseRate / RATE_DECIMAL;
          
      //     memo = "You Win";

      //     if(winners.size()!=0){
      //       winners += "|";
      //     }
      //     winners += bet_itr->player.to_string();
      //     winners += "-";
      //     winners += winCount.to_string();
      //   }else if (game_itr->winner == winState::W_TIE){
      //     //退底注，盲注，加注
      //     winCount = bet_itr->ante_amt + bet_itr->blind_amt + bet_itr->raise_amt;
      //     memo = "Tie";
      //   }else{
      //     memo = "You Lose";
      //   }
      // }

      // if(winCount.amount > 0){
      //   action{
      //     permission_level{get_self(), "active"_n},
      //     "eosio.token"_n,
      //     "transfer"_n,
      //     std::make_tuple(get_self(), bet_itr->player, winCount,
      //     memo)
      //   }.send();
      // }

      // // state_index.modify(bet_itr,get_self(), [&](auto& bet) {
      // //   bet.state = bet_state;
      // //   bet.tx_id = get_transaction_tx();
      // // });

      // reveal_action act{ get_self(), {get_self(), "active"_n}};
      // // act.send(game_itr->id,getCardStrPork(game_itr->poker_player),getCardStrPork(game_itr->poker_flop),getCardStrPork(game_itr->poker_tur),getCardStrPork(game_itr->poker_river),getCardStrPork(game_itr->poker_banker),getCardStrPork(game_itr->player,true),getCardStrPork(game_itr->banker,true),to_string(game_itr->winner),bet_itr->player,bet_itr->ante_amt,bet_itr->blind_amt,bet_itr->color_amt,bet_itr->raise_amt,bet_itr->payout,memo);
    }
    // bet_itr++;
    //erase betInfo
    bet_itr = _betInfo_table.erase(bet_itr);
  }

  finishLog(winners, game_itr->id);
  // if (winners != ""){
  //   data = "{";
  //   pushJsonEx(data,"event_id","gameSettlement");
  //   pushJson(data,"game_id",game_itr->id);
  //   pushJson(data,"state",gameState::FINISH);
  //   pushJsonEx(data,"winners",winners,false);
  //   _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
  //     gameLog.id = getNewLogsIndex();
  //     gameLog.data = data;
  //   });
  // }

  if(bet_itr != _betInfo_table.end()){
    //next settlement
    settelmentNext(count);
    //需要查下和刚刚的是否完成了
    if(settlementId != bet_itr->game_id){
      finishTheGameSettlement(game_itr);
    }
  }else{
    //current game finish
    finishTheGameSettlement(game_itr);
  }

  // eosio::check(1==2,"");
}

dz::globalVars_table::const_iterator dz::getGItr(){
  auto itr = _globalVars_table.begin();
  if(itr == _globalVars_table.end()){
    _globalVars_table.emplace(get_self(), [&](auto& gvars) {
      gvars.id = GLOBALVARS_KEY;
      gvars.public_key = "public_key_default";
    });
    itr = _globalVars_table.begin();
  }
  return itr;
}

//////////////////////////get///////////////////
ACTION dz::setstate(string key,int64_t value){
  require_auth(get_self());
  setValueWithKey(key,value);
}
ACTION dz::delstate(string key){
  require_auth(get_self());
  auto keyValue = std::hash<std::string_view>()(key);
  auto state_itr = _globalState_table.find(keyValue);
  if (state_itr != _globalState_table.end()) {
    _globalState_table.erase(state_itr);
  }
}

int64_t dz::getValueWithkey(string key,int64_t defaultValue){
  auto keyValue = std::hash<std::string_view>()(key);
  auto itr = _globalState_table.find(keyValue);
  if (itr != _globalState_table.end()) {
    return itr->value;
  }else{
    return defaultValue;   //default value
  }
}

void dz::setValueWithKey(string key,int64_t value){
  auto keyValue = std::hash<std::string_view>()(key);
  auto state_itr = _globalState_table.find(keyValue);
  if (state_itr == _globalState_table.end()) {
    _globalState_table.emplace(get_self(), [&](auto& state) {
      state.key = keyValue;
      state.value = value;
    });
  }else{
    _globalState_table.modify(state_itr,get_self(), [&](auto& state) {
      state.value = value;
    });
  }
}

int64_t dz::getTimePreflop(){
    return getValueWithkey(KEY_TIME_PREFLOP, 10);
}
int64_t dz::getTimePDeal(){
    return getValueWithkey(KEY_TIME_PDEAL, 10);
}
int64_t dz::getTimeFlop(){
    return getValueWithkey(KEY_TIME_FLOP, 10);
}
int64_t dz::getTimeTurn(){
    return getValueWithkey(KEY_TIME_TURN, 10);
}
int64_t dz::getTimeRiver(){
    return getValueWithkey(KEY_TIME_RIVER, 10);
}
int64_t dz::getLimitAnte(){
    return getValueWithkey(KEY_LIMIT_ANTE, 200000);
}
int64_t dz::getLimitBlind(){
    return getValueWithkey(KEY_LIMIT_BLIND, 200000);
}
int64_t dz::getLimitColor(){
    return getValueWithkey(KEY_LIMIT_COLOR, 200000);
}
int64_t dz::getLimitRaise(){
    return getValueWithkey(KEY_LIMIT_RAISE, 200000);
}

int64_t dz::getSizepayout(){
  return getValueWithkey(KEY_SIZE_PAYOUT, 10);
}

int64_t dz::getSetIndex(){
  auto index = getValueWithkey(KEY_SET_INDEX, 0);
  index++;
  setValueWithKey(KEY_SET_INDEX,index);
  return index;
}

int64_t dz::getSizeGames(){
  return getValueWithkey(KEY_SIZE_GAMES, 100);
}

int64_t dz::getNewLogsIndex(){
  auto index = getValueWithkey(KEY_CUR_LOGS_INDEX,0);
  index++;
  setValueWithKey(KEY_CUR_LOGS_INDEX,index);
  return index;
}

void dz::deleteOldGameStatus(){
    auto retain = getSizeGames();
    deleteOldTable(_games_table, retain);
    deleteOldTable(_gamesInfo_table, retain);
}

void dz::deleteBets(uint64_t game_id){
  //find bets in this game
  auto gameid_index = _betInfo_table.get_index<name("bygameid")>();
  auto bet_itr = gameid_index.find(game_id);

  while (bet_itr != gameid_index.end() && bet_itr->game_id == game_id) {
    bet_itr = gameid_index.erase(bet_itr);
  }
}

//strOrg=40|55 -> 40[♥8],55[♠7]
std::string dz::getCardStrPork(const std::string &strOrg,bool isHaveType){
  if(strOrg == ""){
    return "";
  }
  std::string cardStr;
  std::vector<std::string> list = splitSV(strOrg, "|");
  uint8_t valueraw = 0;
  auto last = isHaveType ? list.size()-1 : list.size();
  for(int i=0; i<last; i++){
    cardStr += list[i];
    cardStr += "[";
    valueraw = std::atoi(list[i].data());
    cardStr += getCardColorStr(getCardColor(valueraw));
    cardStr += getCardNumStr(getCardValue(valueraw,false));
    cardStr += "]";
    cardStr += ",";
  }
  if(isHaveType){
    auto cardType = std::atoi(list[list.size()-1].data());
    cardStr += dzLogic::typeStr[cardType-1];
  }else{
    cardStr.erase(cardStr.size()-1);
  }
  return cardStr;
}