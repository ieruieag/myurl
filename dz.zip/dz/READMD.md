# dz

This example is to demonstrate a basic EOSIO smart contract, including

- Define contract actions
- Define a table
- Perform read/write/remove operations on the table
