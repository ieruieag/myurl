// #include <string>
// #include <algorithm>
#include "qpcards.hpp"

namespace dzLogic {
	#define	MAX_USER_CARD_COUNT			5								//最大扑克数量

	enum emCardType
	{
		DZ_CARD_TYPE_HIGHCARD = 1,		//单张
		DZ_CARD_TYPE_PAIR = 2,			//对子
		DZ_CARD_TYPE_TWO_PAIR = 3,		//两对
		DZ_CARD_TYPE_THREE_OF_A_KIND = 4,		//三条
		DZ_CARD_TYPE_STRAIGHT = 5,		//顺子
		DZ_CARD_TYPE_FLUSH = 6,		//同花
		DZ_CARD_TYPE_FULL_HOSE = 7,		//葫芦(三条一对)
		DZ_CARD_TYPE_FOUR_OF_A_KIND = 8,		//四条
		DZ_CARD_TYPE_STRAIGHT_FLUSH = 9,		//同花顺
		DZ_CARD_TYPE_ROYAL = 10	    //皇家同花顺(10JQKA)
	};
	const string typeStr[10] = {
      "单张","对子","两对","三条","顺子",
	  "同花","葫芦","四条","同花顺","皇家同花顺"
    };
	
bool IsRoyle(QPCardsClass& cards)
{
	return false;
}

bool IsFlush(QPCardsClass& qpcard)
{
	QP_Cards& cards = qpcard.cards;
	for (int i = 1; i < cards.size(); i++)
	{
		if (cards[i]->m_cardColor != cards[0]->m_cardColor)
		{
			return false;
		}
	}
	qpcard.cardsType = DZ_CARD_TYPE_FLUSH;
	return true;
}

bool IsStraight(QPCardsClass& qpcard)
{
	//cardList必须是降序排列的，才能正确;
	//先看后4张是不是strainght
	QP_Cards& cards = qpcard.cards;
	bool isStraight = true;
	auto len = cards.size();
	for (int i = 1; i < len - 1 ; i++)
	{
		if (cards[i]->m_cardValue - 1 != cards[i+1]->m_cardValue)
		{
			isStraight = false;
			break;
		}
	}
	if (isStraight) {
		if (cards[0]->m_cardValue - 1 == cards[1]->m_cardValue) {
			isStraight = true;
		}
		else if(cards[0]->m_cardValue == 0x0e && cards[len-1]->m_cardValue == 2){
			//A5432
			isStraight = true;
			//->5432A
			cards.push_back(cards[0]);
			cards.erase(cards.begin());
		}
		else
		{
			isStraight = false;
		}
	}
	if (isStraight) {
		qpcard.cardsType = DZ_CARD_TYPE_STRAIGHT;
	}
	return isStraight;
}

//会和qpcard.type(同花或顺子)比较
void GetPairOrHigh(QPCardsClass& qpcard)
{
	std::map<uint8_t, QP_Cards, std::greater<uint8_t>> cardMap; //<牌值,个数, 按牌值降序>
	uint8_t flag = 0;
	QP_Cards &cards = qpcard.cards;
	uint8_t len = cards.size();
	uint8_t val = 0;

	//得到所有一样的牌,保存到cardMap中
	for (uint8_t i = 0; i < len; i++) {
		val = cards[i]->m_cardValue;
		for (uint8_t j = i+1; j < len; j++) {
			if (val == cards[j]->m_cardValue) {
				flag++;
			}
		}
		cardMap[val].push_back(cards[i]);
	}

	int type = DZ_CARD_TYPE_HIGHCARD;
	switch (flag)
	{
	case 6:
		type = DZ_CARD_TYPE_FOUR_OF_A_KIND;
		break;
	case 4:
		type = DZ_CARD_TYPE_FULL_HOSE;
		break;
	case 3:
		type = DZ_CARD_TYPE_THREE_OF_A_KIND;
		break;
	case 2:
		type = DZ_CARD_TYPE_TWO_PAIR;
		break;
	case 1:
		type = DZ_CARD_TYPE_PAIR;
		break;
	default:
		break;
	}

	if (qpcard.cardsType >= type) {
		return;
	}
	qpcard.cardsType = type;
	if (flag > 0) {
		//have pair
		std::vector<std::pair<uint8_t, QP_Cards>> tmpv;	//把cardsMap转成为vector
		for (auto i = cardMap.begin(); i != cardMap.end(); i++) {
			tmpv.push_back(std::make_pair(i->first, i->second));
		}
		//按照牌的数量排序，这样就变成了 数量->牌值的双排序
		std::sort(tmpv.begin(), tmpv.end(),
			[&](const std::pair<uint8_t, QP_Cards>& x, std::pair<uint8_t, QP_Cards>& y) -> int {
				return x.second.size() > y.second.size(); 
			});
		
		//按顺序保存value到数组，后面牌型一样时，比较大小用
		cards.clear();
		for (auto& kv : tmpv) {
			auto count = kv.second.size();
			for (int i = 0; i < count; i++) {
				//qpcard.cardsMax.push_back(kv.first);
				cards.push_back(kv.second[i]);
			}
		}
	}
}

//递归方法
void Combine(QP_Cards& src, int n, int m, std::vector<QPCardsClass>& res)
{
	static int M = m;
	static	std::vector<int> b(M);
	for (int i = m; i <= n; i++) {
		b[m - 1] = i - 1;
		if (m > 1) {
			Combine(src, i - 1, m - 1, res);
		}
		else {
			res.push_back(QPCardsClass());
			QP_Cards &temp = res.rbegin()->cards;
			for (int j = 0; j <= M - 1; j++) {
				temp.push_back(src[b[j]]);
			}
			//res.push_back(temp);
		}
	}
}

//会改变cards的顺序，按照牌型大->小
void GetCardResult(QPCardsClass& qpcard)
{
	QP_Cards& cards = qpcard.cards;
	std::sort(cards.begin(), cards.end(), QPCard::comparisonCard);
	
	//这两个顺序固定，为了大的flush可以覆盖type
	auto isStraight = IsStraight(qpcard);
	auto isFlush = IsFlush(qpcard);

	do {
		if (isFlush && isStraight) {
			if (cards[0]->m_cardValue == BIG_A) {
				//皇家同花
				qpcard.cardsType = DZ_CARD_TYPE_ROYAL;
			}
			else {
				qpcard.cardsType = DZ_CARD_TYPE_STRAIGHT_FLUSH;
			}
			break;	//已经找到最大的
		}

		//里面会比较同花和顺子，因为pair < 同花顺子 < 葫芦
		GetPairOrHigh(qpcard);
	} while (false);
}

void GetCardResults(QPCardsClass& cardsRes, QP_Cards& allCards)
{
	emCardType maxres = DZ_CARD_TYPE_HIGHCARD;
	std::vector<QPCardsClass> allCombineres;

	//排序
	Combine(allCards, allCards.size(), MAX_USER_CARD_COUNT, allCombineres);

	//找到最大的
	auto itr = allCombineres.begin();
	if (itr == allCombineres.end()) {
		//wrong
		return;
	}
	GetCardResult(*itr);
	QPCardsClass& res = *itr;
	if (allCombineres.size() > 1) {
		itr++;
		do
		{
			GetCardResult(*itr);
			if (res < *itr) {
				res = *itr;
			}
			itr++;
		} while (itr != allCombineres.end());
	}
	
	cardsRes = res;
}

}