#include "common.hpp"
#include "dzlogic.hpp"

#define GLOBALVARS_KEY         1
#define USE_SYMBOL             "EOS"
#define KEY_TIME_PREFLOP       "time.preflop"
#define KEY_TIME_PDEAL         "time.pdeal"
#define KEY_TIME_FLOP          "time.flop"
#define KEY_TIME_TURN          "time.turn"
#define KEY_TIME_RIVER         "time.river"
#define KEY_LIMIT_ANTE         "limit.ante"
#define KEY_LIMIT_BLIND        "limit.blind"
#define KEY_LIMIT_COLOR        "limit.color"
#define KEY_LIMIT_RAISE        "limit.raise"
#define KEY_SIZE_GAMES         "size.games"
#define KEY_SIZE_PAYOUT        "size.payout"
#define KEY_SET_INDEX          "set.index" //settelment unique id

#define KEY_CUR_GAME           "curgame"
#define KEY_CUR_LOGS_INDEX     "logsindex"
#define WIN_PLAYER             1
#define WIN_BANKER             2
#define WIN_DRAW               3

struct betInfo {
    std::string_view    action;
    uint64_t            game_id;
    name                player;
    asset               bet_amount;
    asset               bet_ante;
    asset               bet_blind;
    asset               bet_color;
    asset               bet_raise;
    std::string_view    sign;
};

//-------------------------------------------------

//--------------------------------------------------------


CONTRACT dz : public contract {
  public:
    using contract::contract;
    dz(name receiver, name code, datastream<const char*> ds);

    ACTION clearalltable();
    ACTION setstate(string key,int64_t value);
    ACTION delstate(string key);

    ACTION startgame();
    ACTION startbet(uint64_t block_index, string seed_sign);
    ACTION dealplayer(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign);
    ACTION dealflop3(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign);
    ACTION dealturn(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign);
    ACTION dealriver(string block_hash,string seed,uint64_t next_block_index, string next_seed_sign);
    ACTION dealbanker(string block_hash,string seed);
    ACTION fold(name player,uint64_t game_id,string sign);
    
    // ACTION stopbet();
    // ACTION opencards(string sign,string seed,uint64_t block_index,string block_hash);
    ACTION settlement(uint32_t dispose_count,uint32_t count);
    // ACTION cancelgame();

    [[eosio::on_notify("eosio.token::transfer")]] 
    void deposit(name from, name to, eosio::asset quantity, std::string memo);
    TABLE games {
      uint64_t    id;     //pk自增
      uint32_t    state;  //游戏状态 -1暂停 1开始下注 2停止下注 3开牌中 4结算中 5结算完成
      uint64_t    created_at;
      uint64_t    bi_player;        //闲区块号
      string      code_player;      //闲牌型
      string      poker_player;     //牌型显示
      uint64_t    bi_flop;        //闲区块号
      string      code_flop;      //闲牌型
      string      poker_flop;     //牌型显示
      uint64_t    bi_turn;        //闲区块号
      string      code_turn;      //闲牌型
      string      poker_turn;     //牌型显示
      uint64_t    bi_river;        //闲区块号
      string      code_river;      //闲牌型
      string      poker_river;     //牌型显示
      uint64_t    bi_banker;        //闲区块号
      string      code_banker;      //闲牌型
      string      poker_banker;     //牌型显示
      string      player;           //闲最大牌
      string      banker;
      uint32_t    winner;           //赢家 1庄 2闲 3和
      uint32_t    win_card_type;
      auto primary_key() const { return id; }
    };
    typedef multi_index<name("games"), games> games_table;

    TABLE gamesInfo {
      uint64_t    game_id;     //pk自增
      string      sign_player;  
      string      seed_player;      //闲牌型
      string      bh_player;        //牌型显示
      checksum256 tx_player;        //闲区块号
      uint64_t    stop_at_player;   //停止下注时间
      string      sign_flop;
      string      seed_flop;      //闲牌型
      string      bh_flop;        //牌型显示
      checksum256 tx_flop;        //闲区块号
      uint64_t    stop_at_flop;   //停止下注时间
      string      sign_turn;
      string      seed_turn;      //
      string      bh_turn;        //
      checksum256 tx_turn;        //
      uint64_t    stop_at_turn;   //停止下注时间
      string      sign_river;
      string      seed_river;      //
      string      bh_river;        //
      checksum256 tx_river;        //
      uint64_t    stop_at_river;   //停止下注时间
      string      sign_banker;
      string      seed_banker;      //
      string      bh_banker;        //
      checksum256 tx_banker;        //
      auto primary_key() const { return game_id; }
    };
    typedef multi_index<name("gamesinfo"), gamesInfo> gamesInfo_table;

  private:
    enum gameState{
      PAUSE       = 0,
      PRE_FLOP    = 1,  //开局 彩,低,盲
      P_DEAL      = 2,  //闲开2
      FLOP_ROUND  = 3,  //开前3
      TURN_ROUND  = 4,  //开4
      RIVER_ROUND = 5,  //开5
      B_DEAL      = 6,  //庄开2,停止下注,结算中
      FINISH      = 7,
      DRAW        = 8
    };

    enum betState{
      BS_BETTING        = 1,
      WAIT_SETTLEMENT   = 2,
      BS_FOLD           = 3, //弃牌
      BS_FINISH         = 4,
      BS_DRAW           = 5
    };

    enum winState{
      W_BANKER          = 1, //庄
      W_PLAYER          = 2, //闲
      W_TIE             = 3, //和
      W_DRAW            = 4  //流局 
    };

    TABLE globalState {
      uint64_t  key;
      uint64_t  value;
      auto primary_key() const { return key; }
    };
    typedef multi_index<name("globalstate"), globalState> globalState_table;

    TABLE bets {
      uint64_t    id;        //pk自增
      name        player;
      uint64_t    game_id;   //gameStatus.id
      asset       ante_amt;  
      asset       blind_amt;   
      asset       color_amt;
      asset       raise_amt;
      uint64_t    created_at;
      checksum256 tx_id;
      uint32_t    state;
      auto primary_key() const { return id; }
      uint64_t get_player() const { return player.value; }
      uint64_t get_gameid() const { return game_id; }
      uint64_t get_state() const { return state; }
    };
    // typedef multi_index<name("bets"), bets> betInfo_table;
    typedef multi_index<name("bets"), bets
    ,indexed_by<"byplayer"_n, const_mem_fun<bets, uint64_t, &bets::get_player>>
    ,indexed_by<"bygameid"_n, const_mem_fun<bets, uint64_t, &bets::get_gameid>>
    ,indexed_by<"bystate"_n, const_mem_fun<bets, uint64_t, &bets::get_state>>
    > betInfo_table;

    TABLE globalVars {
      uint64_t  id;             //=1,唯一
      uint64_t  cur_game_id;
      uint64_t  next_block_index; //下次开牌区块号
      string    next_seed_sign;   //下次开牌sign
      uint64_t  next_stop_time;
      string    public_key;
      asset     total_ante;    //
      asset     total_blind;   //
      asset     total_color;   //
      asset     total_raise;   //
      asset     game_balance;  //当局游戏余额
      asset     limit_ante;    //
      asset     limit_blind;   //
      asset     limit_color;   //
      asset     limit_raise;   //
      
      auto primary_key() const { return id; }
    };
    typedef multi_index<name("globalvars"), globalVars> globalVars_table;

    TABLE gameLog {
      uint64_t    id;     //pk自增
      string      data;
      auto primary_key() const { return id; }
    };
    typedef multi_index<name("logs"), gameLog> gameLog_table;

    bool analyzeMemo(std::string &memo, betInfo& info,asset& total);
    // void getCardType(string_view);
    //
    // void getCardStr(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType);
    // void getCardStrPork(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType);
    // void analyzeCard(games& game);
    globalVars_table::const_iterator getGItr();

    int64_t getValueWithkey(string key,int64_t defaultValue);
    void    setValueWithKey(string key,int64_t value);
    int64_t getTimePreflop();
    int64_t getTimePDeal();
    int64_t getTimeFlop();
    int64_t getTimeTurn();
    int64_t getTimeRiver();
    int64_t getLimitAnte();
    int64_t getLimitBlind();
    int64_t getLimitColor();
    int64_t getLimitRaise();
    int64_t getSizepayout();
    int64_t getSetIndex();

    int64_t getSizeGames();
    int64_t getNewLogsIndex();
    bool isInSettlement(int32_t state);
    std::string getCardStrPork(const std::string &strOrg,bool isHaveType = false);
    
    void deleteBets(uint64_t game_id);
    void deleteOldGameStatus();
    void commonFlopCard(string &block_hash,string &seed,uint64_t next_block_index,string &next_seed_sign,gameState newState,int cardNum,int64_t time);
    void finish();  //计算结果
    void settelmentNext(uint32_t count);
    void finishTheGameSettlement(games_table::const_iterator game_itr);
    void finishLog(string_view winners,uint64_t id);
    void calculateAndPayment(games_table::const_iterator game_itr,betInfo_table::const_iterator bet_itr, string &winners);

    // bool    isInSettlement(int32_t state);

    globalState_table _globalState_table;
    games_table       _games_table;
    gamesInfo_table   _gamesInfo_table;
    betInfo_table     _betInfo_table;
    globalVars_table  _globalVars_table;
    gameLog_table     _gameLog_table;
    // const float winRate[2] = {195,195};  //balck-1.95 red-1.95
    // const uint8_t strikeRate[7] = {0,0,2,3,3,12,25};  //单张-对子小-对子大-顺子-金花-顺金-豹子
    // const string typeStr[7] = {
    //   "散牌","对子2-8","对子9-A","顺子","金花","顺金","豹子"
    // };
  public:
  
    ACTION bet(uint64_t game_id,name player,asset bet_ante,asset bet_blind,asset bet_color,asset bet_raise,uint32_t state,string sign){
      require_auth(get_self());
    }
    ACTION record(games game,gamesInfo info,string pokers_player,string pokers_flop,string pokers_turn,string pokers_river,string pokers_banker,string best_player,string best_banker,string winner){
      require_auth(get_self());
    }
    ACTION reveal(uint64_t game_id,string pokers_player,string pokers_flop,string pokers_turn,string pokers_river,string pokers_banker,string best_player,string best_banker,string winner,name player,asset ante_amt,asset blind_amt,asset color_amt,asset raise_amt,asset ante_win,asset blind_win,asset color_win,asset raise_win,asset payout){
      require_auth(get_self());
    }

using settlement_action = eosio::action_wrapper<"settlement"_n, &dz::settlement>;
    using bet_action = eosio::action_wrapper<"bet"_n, &dz::bet>;
    using record_action = eosio::action_wrapper<"record"_n, &dz::record>;
    using reveal_action = eosio::action_wrapper<"reveal"_n, &dz::reveal>;

    #define RATE_DECIMAL 100
    const uint16_t colorRate[dzLogic::DZ_CARD_TYPE_ROYAL] = {100,100,100,400,500,
      800,900,3100,4100,5100};
    const uint16_t blindRate[dzLogic::DZ_CARD_TYPE_ROYAL] = {100,100,100,100,200,
    250,400,1100,5100,50100};
    const uint16_t anteRate = 200;
    const uint16_t raiseRate = 200;
    const string winnerStr[4] = {
      "庄赢","闲赢","和局","流局"
    };
};