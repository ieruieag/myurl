#pragma once
#include <vector>

#define EQUAL_TO_LESS_THAN -1	// <
#define EQUAL_TO_EQUAL 0		//==
#define EQUAL_TO_MORE_THAN 1	// >

#define MAX_ALL_CARD_COUNT			52								//最大扑克总数
#define BIG_A						0x0e
#define CARD_TYPE_NONE				-1

class QPCard {
public:
	QPCard(){
		m_isComparasionColor = false;
	}
	QPCard(uint8_t rawVal, bool isComparasionColor = false) {
		reset(rawVal);
		m_isComparasionColor = isComparasionColor;
	}

	inline void reset(uint8_t rawVal) {
		m_cardRawValue = rawVal;
		m_cardColor = rawVal / 16;
		m_cardValue = rawVal % 16;
		if (m_cardValue == 1)
			m_cardValue = BIG_A;
	}

	inline bool operator<(const QPCard& card) {
		auto res = compair(*this, card);
		return res == EQUAL_TO_LESS_THAN;
	}
	inline bool operator>(const QPCard& card) {
		auto res = compair(*this, card);
		return res == EQUAL_TO_MORE_THAN;
	}
	inline bool operator==(const QPCard& card) {
		auto res = compair(*this, card);
		return res == EQUAL_TO_EQUAL;
	}

	uint8_t	m_cardRawValue;		//val + cor * 16
	uint8_t	m_cardValue;		//2-A 2-14
	uint8_t m_cardColor;		//0方块 1梅花 2红桃 3黑桃
	bool    m_isComparasionColor; //是否比较花色

	static inline uint8_t getCardValue(uint8_t card, bool specialA = true) {
		uint8_t value = card % 16;
		if (value == 1 && specialA) {
			//A -> 14
			value = 0x0E;
		}
		return value;
	}

	static inline uint8_t getCardColor(uint8_t card)
	{
		return card / 16;
	}

	static inline int boolToInt(bool b)
	{
		return b ? EQUAL_TO_MORE_THAN : EQUAL_TO_LESS_THAN;
	}

	//降序
	static inline bool comparisonCard(QPCard* a, QPCard* b) {
		return *a > *b;
	}

	static inline int compair(const QPCard& a, const QPCard& b) {
		if (a.m_cardRawValue == b.m_cardRawValue) {
			return EQUAL_TO_EQUAL;
		}
		else if (a.m_cardValue != b.m_cardValue) {
			if (a.m_cardValue > b.m_cardValue) {
				return EQUAL_TO_MORE_THAN;
			}
			else {
				return EQUAL_TO_LESS_THAN;
			}			
		}
		else if (a.m_isComparasionColor) {
			if (a.m_cardColor > b.m_cardColor) {
				return EQUAL_TO_MORE_THAN;
			}
			else {
				return EQUAL_TO_LESS_THAN;
			}
		}
		return EQUAL_TO_EQUAL;	//不算color==
	}

	//1:>    0:==    -1:<   bColor-是否比较花色
	static inline int comparisonRawValue(uint8_t card1, uint8_t card2, bool bColor = true)
	{
		uint8_t cbValue1 = getCardValue(card1);
		uint8_t cbValue2 = getCardValue(card2);
		uint8_t cbFlower1 = getCardColor(card1);
		uint8_t cbFlower2 = getCardColor(card2);

		if (cbValue1 != cbValue2)
		{
			return boolToInt(cbValue1 > cbValue2);
		}
		else if(bColor)
		{
			if(cbFlower1 != cbFlower2)
				return boolToInt(cbFlower1 > cbFlower2);
		}
		return EQUAL_TO_EQUAL;
	}
};

typedef std::vector<uint8_t> QP_Value_Cards;	//value
typedef std::vector<QPCard*> QP_Cards;
//typedef std::vector<QPCard&> QP_Cards_Ex;

class QPCardsClass
{
public:
	QP_Cards		 cards;
	//QP_Value_Cards   cardsMax;		//value,由大到小排序,牌型一样时，比较用
	int				 cardsType;

	QPCardsClass() {
		cardsType = CARD_TYPE_NONE;
	}

	static inline int compair(const QPCardsClass& a, const QPCardsClass& b) {
		if (a.cardsType == b.cardsType) {
			auto len = a.cards.size();
			if (len != b.cards.size()) {
				//wrong
				return EQUAL_TO_LESS_THAN;
			}
			for (int i = 0; i < len; i++) {
				if (*a.cards[i] == *b.cards[i]) {
					continue;
				}
				else if (*a.cards[i] > *b.cards[i]) {
					return EQUAL_TO_MORE_THAN;
				}
				else {
					return EQUAL_TO_LESS_THAN;
				}
			}
			return EQUAL_TO_EQUAL;
		}
		else if (a.cardsType > b.cardsType) {
			return EQUAL_TO_MORE_THAN;
		}
		else {
			return EQUAL_TO_LESS_THAN;
		}
	}

	inline bool operator<(const QPCardsClass& card) {
		auto res = compair(*this, card);
		return res == EQUAL_TO_LESS_THAN;
	}
	inline bool operator>(const QPCardsClass& card) {
		auto res = compair(*this, card);
		return res == EQUAL_TO_MORE_THAN;
		//if (m_cardValue != card.m_cardValue) {
		//	return m_cardValue > card.m_cardValue;
		//}
		//else if (m_cardColor != card.m_cardColor) {
		//	return m_cardColor > card.m_cardColor;
		//}
		//return false;	//==
	}
	inline bool operator==(const QPCardsClass& card) {
		auto res = compair(*this, card);
		return res == EQUAL_TO_EQUAL;
	}
	// 1|23|...|牌型
	void getCardStr(std::string &cardStr){
		cardStr = "";
		for(int i=0; i<cards.size(); i++){
			cardStr += std::to_string(cards[i]->m_cardRawValue);
			cardStr += "|";
		}
		if(cardsType == CARD_TYPE_NONE){
			// cardStr[cardStr.size()-1] = '\0';
			cardStr.erase(cardStr.size()-1);
		}else{
			cardStr += std::to_string(cardsType);
		}
	}
};

