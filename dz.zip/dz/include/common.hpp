#pragma once
#include <eosio/eosio.hpp>
#include <eosio/asset.hpp>
#include <eosio/system.hpp>
#include <eosio/transaction.hpp>
#include <eosio/crypto.hpp>
#include <eosio.token/eosio.token.hpp>
#include "qpcards.hpp"

using namespace std;
using namespace eosio;

#define USE_SYMBOL             "EOS"

template<name::raw TableName, typename T>
void clearTable(multi_index<TableName,T> &table){
  auto g_itr = table.begin();
  while (g_itr != table.end()) {
    g_itr = table.erase(g_itr);
  }
}

template<name::raw TableName, typename T>
inline void deleteOldTable(multi_index<TableName,T> &table,int retainCount){
  //get count
  auto count = 0;
  auto it = table.begin();
  while (it != table.end()) {
    count++;
    it++;
  }
  it = table.begin();
  count = count - retainCount;
  for(int i=0; i<count;i++){
    it = table.erase(it);
  }
}

uint32_t get_current_time(){
  return current_time_point().sec_since_epoch();
}

asset getUserBalance(name user){
  return eosio::token::get_balance(name("eosio.token"),user,symbol(USE_SYMBOL,4).code());
}

template <typename T>
void pushJson(string& ret, std::string_view key, T value,bool bNotLast = true) {
	ret += "\"";
	ret += key;
	ret += "\":";
	ret += std::to_string(value);
	if (bNotLast) {
		ret += ",";
	}
	else {
		ret += "}";
	}
}
void pushJsonEx(string& ret, std::string_view key, std::string_view value, bool bNotLast = true) {
	ret += "\"";
	ret += key;
	ret += "\":\"";
	ret += value;
	ret += "\"";
	if (bNotLast) {
		ret += ",";
	}
	else {
		ret += "}";
	}
}

void toHex(const void* data, uint32_t len, std::string& hexStr) {
    constexpr static uint32_t max_stack_buffer_size = 513;
    const char* hex_characters = "0123456789abcdef";

    uint32_t buffer_size = 2 * len + 1;
    if (buffer_size < len) return;

    void* buffer;
    buffer = malloc(buffer_size);
    // if (max_stack_buffer_size < buffer_size) {
    //     buffer = malloc(buffer_size);
    // }
    // else {
    //     buffer = alloca(buffer_size);
    // }
    memset(buffer, 0, buffer_size);
    
    char* b = reinterpret_cast<char*>(buffer);
    const uint8_t* d = reinterpret_cast<const uint8_t*>(data);
    for (uint32_t i = 0; i < len; ++i) {
        *b = hex_characters[d[i] >> 4];
        ++b;
        *b = hex_characters[d[i] & 0x0f];
        ++b;
    }

    hexStr = (char*)buffer;
    memset(buffer, 0, buffer_size);
    free(buffer);
    // if (max_stack_buffer_size < buffer_size) {
    //     free(buffer);
    // }
}

checksum256 get_transaction_tx() {
  auto size = transaction_size();
  char buf[size];
  uint32_t read = read_transaction( buf, size );
  eosio::check( size == read, "read_transaction failed");
  return eosio::sha256(buf, read);
}

void get_transaction_tx(std::string &tx_id) {
  auto hash = get_transaction_tx();
  auto dataArray = hash.extract_as_byte_array();
  toHex(dataArray.data(),dataArray.size(),tx_id);
}

//获取牌的整个code
void getCardsCode(string &seed,string &block_hash,string &code){
  size_t begin = 0;
  //get last 32 char
  if(block_hash.size() >= 32)
    begin = block_hash.size() - 32;
  string baseStr = seed + block_hash.substr(begin,32);

  // //get card hex
  checksum256 wash_hash = eosio::sha256(baseStr.c_str(), baseStr.size());
  auto dataArray = wash_hash.extract_as_byte_array();
  toHex(dataArray.data(),dataArray.size(),code);
}

//----------------analyze card------------
bool isValid(std::string_view hash, int begin) {
    return 0 < begin && begin < hash.size();
}

//begin 从右到左
uint8_t getCard(std::string_view hash, size_t& begin) {
    if (!isValid(hash, begin))
        return -1;
    uint8_t numCard = -1;
    uint8_t numColor = -1;
    char c = '0';
    do
    {
        //card
        c = hash[begin];
        numCard = std::strtol(&c, NULL, 16);
        begin--;
        //1-9abcd
        if (numCard < 1 || numCard > 0xD) {
            continue;
        }
        if (!isValid(hash, begin))
            break;
        //color (0-f)%4
        c = hash[begin];
        numColor = std::strtol(&c, NULL, 16) % 4;
        begin--;
        break;
    } while (isValid(hash, begin));
    return numCard + numColor * 16;
}

void getMultiCard(std::string_view hash, size_t& begin, QP_Value_Cards& allCard,QP_Value_Cards& existedCards,size_t num) {
    uint8_t oneCard;
    do
    {
        oneCard = getCard(hash, begin);
        auto it = std::find(existedCards.begin(), existedCards.end(), oneCard);
        if (it != existedCards.end()) {
            continue;
        }
        allCard.push_back(oneCard);
        existedCards.push_back(oneCard);

    } while (allCard.size() < num && isValid(hash, begin));
}
//---------------------------------------------
void getCardStr(std::string &cardStr,QP_Value_Cards &cards,int cardType=CARD_TYPE_NONE){
  cardStr = "";
  for(int i=0; i<cards.size(); i++){
    cardStr += std::to_string(cards[i]);
    if(i+1 != cards.size()){
      cardStr += "|";
    }
  }
  // if(cardType == CARD_TYPE_NONE){
  //   // cardStr[cardStr.size()-1] = '\0';
  //   cardStr.erase(cardStr.size()-1);
  // }
  if(cardType != CARD_TYPE_NONE){
    cardStr += std::to_string(cardType);
  }
}

std::string getCardNumStr(short numCard) {
    if (1 < numCard && numCard < 11) {
        //2-10
        return std::to_string(numCard);
    }
    switch (numCard) {
    case 1:
        return "A";
    case 11:
        return "J";
    case 12:
        return "Q";
    case 13:
        return "K";
    }
    return "";
}

std::string getCardColorStr(short numColor) {
    switch (numColor)
    {
        case 0:
           return "♦";
        case 1:
           return "♣";
        case 2:
           return "♥";
        case 3:
           return "♠";
    }
    return "";
}

//specialA -> A会特殊处理成功0x0e
inline uint8_t getCardValue(uint8_t card, bool specialA = true)
{
	uint8_t value = card % 16;
	if (value == 1 && specialA) {
		//A -> 14
		value = 0x0E;
	}
	return value;
}

inline uint8_t getCardColor(uint8_t card)
{
	return card / 16;
}



//-----------------------------------------------
std::vector<std::string>
splitSV(const std::string &strv, std::string_view delims = " ")
{
    std::vector<std::string> output;
    size_t first = 0;

    while (first < strv.size())
    {
        const auto second = strv.find_first_of(delims, first);
        if (first != second)
            output.emplace_back(strv.substr(first, second - first));

        if (second == std::string::npos)
            break;

        first = second + 1;
    }
    return output;
}

//返回的是int,但不会有负数
int64_t floatStrToInt(std::string num) {
    num.erase(std::remove(num.begin(), num.end(), '.'), num.end());
    int64_t ret = std::strtoll(num.c_str(),NULL,10);
    eosio::check(ret >= 0, "bet cant be minus");
    return ret;
}