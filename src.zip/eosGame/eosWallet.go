package eosGame

import (
	"fmt"
	"github.com/eoscanada/eos-go"
	pkwallet "project"
	"sync"
	"time"
	"xvx.com/fxasync"
)

type QueueMutex struct {
	queue map[string]int
	mutex sync.Mutex
}

func (p* QueueMutex) Add(txid string) {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	if _,ok := p.queue[txid]; !ok{
		p.queue[txid] = 100
	}
}

func (p* QueueMutex) Remove(txid string, txidQueue *QueueMutex) {
	txidQueue.mutex.Lock()
	defer txidQueue.mutex.Unlock()

	if _,ok := txidQueue.queue[txid]; !ok{
		delete(txidQueue.queue, txid)
	}
}

type EosAccount struct {
	pos 	eos.Int64		//已经处理了交易的pos
	balance eos.Asset
	name    eos.Name
}

type EosManager struct {
	txidUnSuccessedQueue		QueueMutex	//没有确定上链的txid int 已经尝试的次数
	txidSuccessedQueue			QueueMutex	//近期成功上链的txid
	eosHistory 					EosHistory
	eosAccount					EosAccount
}

func (p* EosManager) CheckTrans() {
	//timer := time.NewTicker(time.Second)
	for{
		for txid := range p.txidUnSuccessedQueue.queue{
			//todo: 加个状态, 来保证同一时间不会重复GetTransaction,当在获取，则跳过
			p.eosHistory.GetTransaction(txid)
		}
		time.Sleep(10)
	}
}

//获取对应account该处理的txid的pos 读取失败等就返回0
func (p* WalletDB) GetEosAccountPos(account string) eos.Int64{
	var pos eos.Int64 = 0
	sql := fmt.Sprintf("select t.pos from t_dapp_accounts t where t.name = '%s' and t.chaintype = 'EOS'",
		account)

	stmt := p.db.PrepareStmt(sql)
	defer stmt.Close()
	if stmt != nil{
		rec := stmt.ExecQuery()
		if rec.Next(){
			rec.Scan(pos)
			return pos
		}
	}
	return pos
}

func (p* EosManager) UpdateAccountPos(){
	p.eosAccount.pos = GetEosAccountPos(account)
}

func (p* EosManager) CheckAccounts() {
	p.UpdateAccountPos()
	for{
		p.eosAccount.pos = p.eosHistory.GetActionsByAccount(p.eosAccount.name, p.eosAccount.pos)
		time.Sleep(1)
	}
}

func (p* EosManager) Start() {
	//fxasync.AsyncRunCoroutine(func() {
	//	p.CheckTrans()
	//})
	fxasync.AsyncRunCoroutine(func() {
		p.CheckAccounts()
	})
}

//func (p *EosManager) EosTransIn(pkTransIn pkwallet.PK_CA_TRANS_IN_EOS) {
//	//save to db
//
//	//加入全局检查txid的队列
//	p.txidUnSuccessedQueue.Add(pkTransIn.Txid)
//}

func (p *EosManager) EosTransOut(pkTransOut pkwallet.PK_CA_TRANS_OUT_EOS) {
	//save to db

	//加入全局检查txid的队列
	p.txidUnSuccessedQueue.Add(pkTransIn.Txid)
}

func (p *GameServer) depositEos(memo string, amount eos.Int64){
	account := "eosio.token"
	from := eos.AccountName(Player)

	action := &eos.Action{
		Account: eos.AN(account),
		Name:	 eos.ActN("transfer"),
		Authorization: []eos.PermissionLevel{
			{Actor: from, Permission: eos.PN("active")},
		},
		ActionData: eos.NewActionData(data),
	}
}