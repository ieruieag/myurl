package eosGame

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/eoscanada/eos-go"
	"github.com/eoscanada/eos-go/token"
	"eosGame/egames"
	"go.uber.org/atomic"
	"time"
	"xvx.com/fxlog"
	"xvx.com/ucdata"
)

const(
	EGAME_TYPE_ZJH		=	"EZJH"
)

type EosHistory struct {
	GameType	string
}

func (p *EosHistory) EosTransactionFailed(trans *eos.TransactionResp)  {
	txid := trans.ID.String()
	blockNum := trans.BlockNum
	uclog.LogInfo(fxlog.FACILITY_APP,"EosTransactionFailed id=%s blockNum=%d", txid, blockNum)
}

//转账
func (p *EosHistory) EosioTokenTransferHandler(trace *eos.ActionTrace) error{
	txid := trace.TransactionID.String()
	blockNum := trace.BlockNum
	tranParam := token.Transfer{}
	bJson,err := json.Marshal(trace.Action.Data)
	if err != nil{
		return err
	}

	err = json.Unmarshal(bJson, &tranParam)
	if err != nil{
		uclog.LogInfo(fxlog.FACILITY_APP,"EosioTokenTransferHandler unmarshal failed id=%s blockNum=%d err=%v bJson=%s",
			txid, blockNum, err, string(bJson))
		return err
	}

	//update db

	gEosManager.txidUnSuccessedQueue.Remove(txid)
	uclog.LogInfo(fxlog.FACILITY_APP,"EosioTokenTransferHandler succeed id=%s blockNum=%d",
		txid, blockNum)
}

func (p *EosHistory) EosioTokenHandler(trace *eos.ActionTrace) error{
	txid := trace.TransactionID.String()
	blockNum := trace.BlockNum
	uclog.LogInfo(fxlog.FACILITY_APP,"EosioTokenHandler id=%s blockNum=%d actionName=%s",
		txid, blockNum, trace.Action.Name)

	switch trace.Action.Name {
	case "transfer":
		p.EosioTokenTransferHandler(trace)
	}
}

//millisecond
func GetCurrentTime() int64 {
	return time.Now().UnixNano()/1e6
}

func (p *WalletDB) UpdateAccountPos(account string, pos eos.Int64, txid string){
	fn := func() int{
		ret := def.ERR_OK
		params := ucdata.NewProcParams()
		startTime := GetCurrentTime()

		params.AddParam(ucdata.ParamInput, "p_name", account)
		params.AddParam(ucdata.ParamInput, "p_pos", pos)

		_, err := p.db.ExcuteStoredProc("pk_eos_account.updateAccountPos")
		endTime := GetCurrentTime()
		span := endTime-startTime

		if err != nil{
			uclog.LogError(uclog.FACILITY_APP,"UpdateAccountPos failed account=%s pos=%d txid=%s err=%v",
				account, pos, txid, err)
			ret = def.ERR_DB
		}else{
			uclog.LogInfo(uclog.FACILITY_APP,"UpdateAccountPos succeed account=%s pos=%d txid=%s",
				account, pos, txid)
		}
		return ret
	}
	p.chSaveDB <- fn
}

func (p *EosHistory) EosActionHandlerByAccount(trace *eos.ActionTrace,pos eos.Int64){
	err := p.EosActionHandler(trace)
	//insert to db
	var status int
	if err == nil{
		status = 1
	}else{
		status = 0
	}
	txid := trace.TransactionID.String()
	blockNum := trace.BlockNum
	blockTime := trace.BlockTime
	account := trace.Action.Account
	actionName := trace.Action.Name
	actiondata, _ := json.Marshal(trace.Action.ActionData.Data)

	sql := fmt.Sprintf("insert into T_DAPP_TRANS (TRANS_HASH, ACTION_DATA, ACTION_TYPE, CREATE_TIME, INDENT, " +
		"BLOCK_NUM,BLOCK_TIME,ACCOUNT, STATUS) VALUEES ('%s', '%s', '%s', sysdate, '%s', %d, %d, '%s' , %d)",
		txid, string(actiondata), actionName, "ident", blockNum, blockTime, account, status)

	pStmIn := p.db.PrepareStmt(sql)
	defer pStmIn.Close()
	_, err := pStmIn.ExecUpdate()
	if err != nil{
		uclog.LogError(uclog.FACILITY_APP,"EosActionHandlerByAccount to db failed id=%s blockNum=%d actionName=%s",
			txid, blockNum, trace.Action.Name)
	}

	//update pos
	p.db.UpdateAccountPos(account,pos,txid)
}

func (p *EosHistory) EosActionHandler(trace *eos.ActionTrace) error{
	err := errors.New("nohandler")
	//分发处理
	switch trace.Action.Account {
	case "eosio.token":
		err = p.EosioTokenHandler(trace)
	}

	switch p.GameType {
	case EGAME_TYPE_ZJH:
		err = egames.ZjhActionTraceHandler(trace)
	}
	//统一处理
	switch trace.Action.Name {

	}

	print(trace.Receipt.ActionDigest.String())
	print(" " + trace.TransactionID.String() + "\n")
	return err
}

func (p *EosHistory) EosTransactionSuccessed(trans *eos.TransactionResp)  {
	traces := make(map[string]int)	//记录已经处理过的trace,比如transfer就有3个一样的trace
	var digest string
	for _,trace := range trans.Traces{
		digest = trace.Receipt.ActionDigest.String()
		if _,ok := traces[digest]; !ok{
			//没处理过的trace
			p.EosActionHandler(&trace)
		}
		traces[digest] = 1
	}
}

func (p *EosHistory) handleEosTransaction(trans *eos.TransactionResp)  {
	switch trans.Receipt.Status {
	case eos.TransactionStatusDelayed:
		return
	case eos.TransactionStatusSoftFail:
		fallthrough
	case eos.TransactionStatusHardFail:
		fallthrough
	case eos.TransactionStatusExpired:
		//log
		p.EosTransactionFailed(trans)
	case eos.TransactionStatusExecuted:
		p.EosTransactionSuccessed(trans)
	}
}

func (p *EosHistory) GetTransaction(txid string)  {
	uclog.LogInfo(fxlog.FACILITY_APP,"GetTransaction id=%s begin", txid, err)
	rsp,err := myeos.Api.GetTransaction(context.Background(), txid)
	if err == nil {
		p.handleEosTransaction(rsp)
	}else{
		uclog.LogInfo(uclog.FACILITY_APP,"GetTransaction id=%s failed, err = %v", txid, err)
	}
}

//posBegin第一个action的位置  posEnd-处理到那个action的位置
func (p *EosHistory) handleEosAccountActions(actions *eos.ActionsResp,posBegin eos.Int64) (posEnd eos.Int64) {
	//todo LastIrreversibleBlock也应该考虑  还要加入pos没有处理的
	posEnd = posBegin
	for _,action := range actions.Actions{
		p.EosActionHandlerByAccount(&action.Trace,posEnd)
		posEnd++
	}
	return
}

//posBegin第一个action的位置  posEnd-处理到那个action的位置
func (p *EosHistory) GetActionsByAccount(account string,posBegin eos.Int64) (posEnd eos.Int64) {
	rsp,err := myeos.Api.GetActions(context.Background(),eos.GetActionsRequest{
		eos.AN(account),posBegin,0})
	if err == nil {
		posEnd = p.handleEosAccountActions(rsp, posBegin)
	}else{
		uclog.LogInfo(uclog.FACILITY_APP,"GetActionsByAccount account=%s failed, pos=%d, err = %v", account, posBegin,err)
	}
	return
}

