package egames

import "github.com/eoscanada/eos-go"
type Act_zjh_start_bet struct {
	block_index   uint64           `json:"block_index"`
	sign		  string           `json:"sign"`
	public_key    string           `json:"public_key"`
}

type Act_zjh_open_cards struct {
	sign		  bool             `json:"sign"`
	seed		  bool             `json:"seed"`
	block_index   uint64           `json:"block_index"`
}

type Act_zjh_settlement struct {
	dispose_count bool             `json:"dispose_count"`
	count		  bool             `json:"count"`
}

type Act_zjh_beton struct {
	from		  string           `json:"from"`
	quantity	  eos.Asset        `json:"quantity"`
	memo		  string           `json:"memo"`
}

//给谁加钱
type Act_zjh_deposit struct {
	from		  string           `json:"from"`
	quantity	  eos.Asset        `json:"quantity"`
}

//提款
type Act_zjh_withdraw struct {
	from		  string           `json:"from"`
	quantity	  eos.Asset        `json:"quantity"`
}

type Act_zjh_setstate struct {
	key			  string           `json:"key"`
	value		  int64		       `json:"value"`
}

type Act_zjh_delstate struct {
	key			  string           `json:"key"`
}

const (
	zjh_start_bet = "startbet"
	zjh_stop_bet = "stopbet"
	zjh_open_cards = "opencards"
	zjh_settlement = "settlement"
	zjh_cancelgame = "cancelgame"
	zjh_beton = "beton"
	zjh_deposit = "deposit"
	zjh_withdraw = "withdraw"
	zjh_setstate = "setstate"
	zjh_delstate = "delstate"
)

func ZjhActionTraceHandler(trace *eos.ActionTrace) error {
	return nil
}

func startGame(){
	data := &Act_zjh_start_bet{
		block_index: 0,
		sign:        p.seedsign,
		public_key:  "",
	}

	_, err := token.Push_Action_To_TransactionEx(zjh_start_bet, *data, )
}
