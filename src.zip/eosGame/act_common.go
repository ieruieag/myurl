package eosGame

import "github.com/eoscanada/eos-go"

type Act_zjh_start_bet struct {
	block_index   uint64           `json:"block_index"`
	sign		  string           `json:"sign"`
	public_key    string           `json:"public_key"`
}

type Act_zjh_open_cards struct {
	sign		  bool             `json:"sign"`
	seed		  bool             `json:"seed"`
	block_index   uint64           `json:"block_index"`
}

type Act_zjh_settlement struct {
	dispose_count bool             `json:"dispose_count"`
	count		  bool             `json:"count"`
}

type Act_zjh_beton struct {
	from		  string           `json:"from"`
	quantity	  eos.Asset        `json:"quantity"`
	memo		  string           `json:"memo"`
}

//给谁加钱
type Act_zjh_deposit struct {
	from		  string           `json:"from"`
	quantity	  eos.Asset        `json:"quantity"`
}

//提款
type Act_zjh_withdraw struct {
	from		  string           `json:"from"`
	quantity	  eos.Asset        `json:"quantity"`
}

type Act_zjh_setstate struct {
	key			  string           `json:"key"`
	value		  int64		       `json:"value"`
}

type Act_zjh_delstate struct {
	key			  string           `json:"key"`
}