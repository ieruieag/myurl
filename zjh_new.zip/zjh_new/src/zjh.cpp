#include <zjh.hpp>
#include <eosio/system.hpp>
#include <string>
#include <eosio/transaction.hpp>
#include <eosio/crypto.hpp>
#include <eosio.token/eosio.token.hpp>

template <typename T>
void pushJson(string& ret, std::string_view key, T value,bool bNotLast = true) {
	ret += "\"";
	ret += key;
	ret += "\":";
	ret += std::to_string(value);
	if (bNotLast) {
		ret += ",";
	}
	else {
		ret += "}";
	}
}
void pushJsonEx(string& ret, std::string_view key, std::string_view value, bool bNotLast = true) {
	ret += "\"";
	ret += key;
	ret += "\":\"";
	ret += value;
	ret += "\"";
	if (bNotLast) {
		ret += ",";
	}
	else {
		ret += "}";
	}
}

std::string getCardNumStr(short numCard) {
    if (1 < numCard && numCard < 11) {
        //2-10
        return std::to_string(numCard);
    }
    switch (numCard) {
    case 1:
        return "A";
    case 11:
        return "J";
    case 12:
        return "Q";
    case 13:
        return "K";
    }
    return "";
}

std::string getCardColorStr(short numColor) {
    switch (numColor)
    {
        case 0:
           return "♦";
        case 1:
           return "♣";
        case 2:
           return "♥";
        case 3:
           return "♠";
    }
    return "";
}

asset getUserBalance(name user){
  return eosio::token::get_balance(name("eosio.token"),user,symbol(USE_SYMBOL,4).code());
}

//返回的是int,但不会有负数
int64_t floatStrToInt(std::string num) {
    num.erase(std::remove(num.begin(), num.end(), '.'), num.end());
    int64_t ret = std::strtoll(num.c_str(),NULL,10);
    eosio::check(ret >= 0, "bet cant be minus");
    return ret;
}

//----------------analyze card------------
bool isValid(std::string_view hash, int begin) {
    return 0 < begin && begin < hash.size();
}

uint8_t getCard(std::string_view hash, size_t& begin) {
    if (!isValid(hash, begin))
        return -1;
    uint8_t numCard = -1;
    uint8_t numColor = -1;
    char c = '0';
    do
    {
        //card
        c = hash[begin];
        numCard = std::strtol(&c, NULL, 16);
        begin--;
        if (numCard < 1 || numCard > 0xD) {
            continue;
        }
        if (!isValid(hash, begin))
            break;
        //color
        c = hash[begin];
        numColor = std::strtol(&c, NULL, 16) % 4;
        begin--;
        break;
    } while (isValid(hash, begin));
    return numCard + numColor * 16;
}

void getMultiCard(std::string_view hash, size_t& begin, QP_Cards& allCard,size_t num) {
    uint8_t oneCard;
    do
    {
        oneCard = getCard(hash, begin);
        auto it = std::find(allCard.begin(), allCard.end(), oneCard);
        if (it != allCard.end()) {
            continue;
        }
        allCard.push_back(oneCard);

    } while (allCard.size() < num && isValid(hash, begin));
}
//---------------------------------------------

std::vector<std::string_view>
splitSV(std::string_view strv, std::string_view delims = " ")
{
    std::vector<std::string_view> output;
    size_t first = 0;

    while (first < strv.size())
    {
        const auto second = strv.find_first_of(delims, first);
        if (first != second)
            output.emplace_back(strv.substr(first, second - first));

        if (second == std::string_view::npos)
            break;

        first = second + 1;
    }
    return output;
}

uint32_t get_current_time(){
  return current_time_point().sec_since_epoch();
}

void toHex(const void* data, uint32_t len, std::string& hexStr) {
    constexpr static uint32_t max_stack_buffer_size = 513;
    const char* hex_characters = "0123456789abcdef";

    uint32_t buffer_size = 2 * len + 1;
    if (buffer_size < len) return;

    void* buffer;
    if (max_stack_buffer_size < buffer_size) {
        buffer = malloc(buffer_size);
    }
    else {
        buffer = alloca(buffer_size);
    }
    memset(buffer, 0, buffer_size);
    
    char* b = reinterpret_cast<char*>(buffer);
    const uint8_t* d = reinterpret_cast<const uint8_t*>(data);
    for (uint32_t i = 0; i < len; ++i) {
        *b = hex_characters[d[i] >> 4];
        ++b;
        *b = hex_characters[d[i] & 0x0f];
        ++b;
    }

    hexStr = (char*)buffer;
    if (max_stack_buffer_size < buffer_size) {
        free(buffer);
    }
}

checksum256 get_transaction_tx() {
  auto size = transaction_size();
  char buf[size];
  uint32_t read = read_transaction( buf, size );
  eosio::check( size == read, "read_transaction failed");
  return eosio::sha256(buf, read);
}

void get_transaction_tx(std::string &tx_id) {
  auto hash = get_transaction_tx();
  auto dataArray = hash.extract_as_byte_array();
  toHex(dataArray.data(),dataArray.size(),tx_id);
}

zjh::zjh(name receiver, name code, datastream<const char*> ds)
: contract(receiver, code, ds), 
  _globalState_table(receiver, receiver.value),
  _gameStatus_table(receiver, receiver.value),
  _betInfo_table(receiver, receiver.value),
  _gameLog_table(receiver, receiver.value),
  _gameLog2_table(receiver, receiver.value),
  _accounts_table(receiver, receiver.value)
{}

bool zjh::analyzeMemo(std::string memo, betInfo& info,asset& total) {
    std::vector<std::string_view> infos = splitSV(memo, "|");
    //check
    eosio::check(infos.size() == 10, "memo not include 9 info");
    if(infos.size() != 10){
      return false;
    }
    info.action     = infos[0];
    info.game_id    = std::stoll(infos[1].data());
    info.player     = name(infos[2]);
    info.bet_amount = asset(floatStrToInt(infos[3].data()),total.symbol);
    info.bet_black  = asset(floatStrToInt(infos[4].data()),total.symbol);
    info.bet_red    = asset(floatStrToInt(infos[5].data()),total.symbol);
    info.bet_strike = asset(floatStrToInt(infos[6].data()),total.symbol);
    info.sign = infos[7];
    info.seq  = std::stoll(infos[8].data());
    info.svr_id  = infos[9];

    eosio::check(total == info.bet_black + info.bet_red + info.bet_strike,
    "bet amount not match memo = " + memo + "total = " + total.to_string());
    return true;
}

//------------------zjhlogic-----
bool zjhLogic::isSameFlower(QP_Cards& cards)
{
    uint8_t cbFlower = getCardColor(cards[0]);
    for (int i = 1; i < cards.size(); i++)
    {
        if (getCardColor(cards[i]) != cbFlower)
        {
            return false;
        }
    }
    return true;
}

bool zjhLogic::IsSunZi(ZJH_Cards& cards)
{
    //cardList必须是SortCardList(CardList)以后的，才能正确;
    if (cards[0] == 0x03 && cards[1] == 0x02 && cards[2] == 0x0E)
    {
		//32A
        return true;
    }
    if (cards[0] - cards[1] == 1 && cards[1] - cards[2] == 1)
    {
        return true;
    }
    return false;
}

bool zjhLogic::isBaoZi(ZJH_Cards& cards)
{
    //cardList必须是SortCardList(CardList)以后的，才能正确;
    if (cards[0] == cards[1] && cards[0] == cards[2])
    {
        return true;
    }
    return false;
}

bool zjhLogic::isDuiZi(ZJH_Cards& cards)
{
    //cardList必须是SortCardListEx以后的，才能正确;
	if (cards[0] == cards[1] && cards[1] != cards[2])
	{
		return true;
	}
	//SortCardListEx后没有ABB已经是BBA了
	return false;
}

//会改变cardList的顺序
void zjhLogic::resort(QP_Cards& cardList)
{
	uint8_t card1 = getCardValue(cardList[0]);
	uint8_t card2 = getCardValue(cardList[1]);
	uint8_t card3 = getCardValue(cardList[2]);

	if (card1 == 0x0e && card2 == 0x03 && card3 == 0x02)
	{
		//A32 -> 32A compareCard依赖
		uint8_t wDiffData = cardList[0];
		cardList[0] = cardList[1];
		cardList[1] = cardList[2];
		cardList[2] = wDiffData;
	}
	else if (card1 != card2 && card2 == card3)
	{
		//ABB -> BBA compareCard依赖
		uint8_t wDiffData = cardList[0];
		cardList[0] = cardList[2];
		cardList[2] = wDiffData;
	}
}

zjhLogic::emCardType zjhLogic::getCardType(QP_Cards& cardList, ZJH_Cards& cards)
{
	sortCardListEx(cardList);
  //cards中的A=14
	cards[0] = getCardValue(cardList[0]);
	cards[1] = getCardValue(cardList[1]);
	cards[2] = getCardValue(cardList[2]);

    //是否豹子
	if (isBaoZi(cards))
	{
		return CARD_TYPE_BAOZI;
	}
  bool isSameColor = isSameFlower(cardList);
  bool isSunZi = IsSunZi(cards);

  if (isSameColor && isSunZi) {
      return CARD_TYPE_SHUNJIN;
  }

	if (isSameColor) {
		return CARD_TYPE_JINHUA;
	}

  if (isSunZi) {
      return CARD_TYPE_SHUNZI;
  }

  if (isDuiZi(cards) ) {
      if(cards[0] < 9){
        //2-8的对子
        return CARD_TYPE_DUIZI_MIN;
      }else{
        //9-A的对子
        return CARD_TYPE_DUIZI_BIG;
      }
  }

  return CARD_TYPE_DANZHANG;
}

void zjhLogic::sortCardListEx(QP_Cards& cardList)
{
	sortCardList(cardList);
	resort(cardList);
}

//先获取type,在进行比较
bool zjhLogic::compareCard(QP_Cards left, emCardType& lType, QP_Cards right, emCardType& rType)
{
	ZJH_Cards cardsLeft;
	ZJH_Cards cardsRight;
	lType = getCardType(left, cardsLeft);
	rType = getCardType(right, cardsRight);
    //前提left和right都是从大到小排列的,依赖getCardType中的排序
	if (lType != rType)
	{
		return lType > rType;
	}
	for (int i = 0; i < MAX_USER_CARD_COUNT; i++)
	{
		if (cardsLeft[i] != cardsRight[i])
		{
			return cardsLeft[i] > cardsRight[i];
		}
	}

	//完全一样的，比对最大的牌的花色
    //例外32A-> 比3的花色   对子-> 比单张cards[2]的花色
	int num = 0;	//要比第几张牌的花色
	if (lType == CARD_TYPE_DUIZI_MIN || lType == CARD_TYPE_DUIZI_BIG) {
		//比单张cards[2]的花色
		num = 2;
	}
	return getCardColor(left[num]) > getCardColor(right[num]);
}
//-------------------------------
void zjh::getCardStr(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType){
  for(int i=0; i<cards.size(); i++){
    cardStr += std::to_string(cards[i]);
    cardStr += "|";
  }
  cardStr += std::to_string(cardType);
}

void zjh::getCardStrPork(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType){
  for(int i=0; i<cards.size(); i++){
    cardStr += std::to_string(cards[i]);
    cardStr += "[";
    cardStr += getCardColorStr(getCardColor(cards[i]));
    cardStr += getCardNumStr(getCardValue(cards[i],false));
    cardStr += "]";
    cardStr += ",";
  }
  cardStr += typeStr[cardType-1];
}

//会修改game内容:black_card,red_card,winner,win_card_type
void zjh::analyzeCard(gameStatus& game){
  //get card
  std::string hexStr = game.wash_hash;
  size_t begin = hexStr.size() - 1;
  QP_Cards allcard;
  QP_Cards black;
  QP_Cards red;
  getMultiCard(hexStr, begin, allcard, 6);
  // getMultiCard(hexStr, begin, black, 3);
  // getMultiCard(hexStr, begin, red, 3);
  eosio::check(allcard.size() == 6,hexStr + " can't get card");
  // eosio::check(red.size() == 3,hexStr + " can't get red card");
  black.insert(black.begin(),allcard.begin(),allcard.begin()+3);
  red.insert(red.begin(),allcard.begin()+3,allcard.begin()+6);

  // zjhLogic::ZJH_Cards blackValue;
  // zjhLogic::ZJH_Cards redValue;
  zjhLogic::emCardType balckType;
  zjhLogic::emCardType redType;
  auto isBlackWin = zjhLogic::compareCard(black,balckType,red,redType);

  getCardStr(game.black_card,black,balckType);
  getCardStr(game.red_card,red,redType);
  getCardStrPork(game.black_pork,black,balckType);
  getCardStrPork(game.red_pork,red,redType);
  if(isBlackWin){
    game.winner = WIN_BLACK;
    game.win_card_type = balckType;
  }else{
    game.winner = WIN_RED;
    game.win_card_type = redType;
  }
}

void zjh::betonFunc(name from,eosio::asset quantity, string &memo){
  eosio::check(quantity.symbol.code().to_string()==USE_SYMBOL,"only support eos token not "+quantity.symbol.code().to_string());

  betInfo info;
  if(!analyzeMemo(memo,info,quantity)){
    return;
  }
  //check game is betting
  auto game_itr = _gameStatus_table.find(info.game_id);
  eosio::check(game_itr != _gameStatus_table.end(), "cant find this game");
  eosio::check(game_itr->state == gameState::BETTING, "game is not in betting");
  //check bet is valid
  eosio::check(quantity.amount <= getCurMaxBet(), "exceeded max bet");
  eosio::check(info.bet_strike.amount <= getStrikeCurMaxBet(), "exceeded max strike bet");
  //check sign
  // eosio::check(info.sign==game_itr->sign, "wrong sign");
  eosio::check(game_itr->stop_at>get_current_time(), "is stop time");

  _gameStatus_table.modify(game_itr,get_self(), [&](auto& game) {
    game.bet_black   += info.bet_black;
    game.bet_red     += info.bet_red;
    game.bet_strike  += info.bet_strike;
    game.sys_balance =  getUserBalance(get_self());
  });
  //write log
  string data;
  data += "{";
  pushJsonEx(data,"event_id","newBet");
  pushJson(data,"game_id",info.game_id);
  pushJson(data,"state",gameState::BETTING);
  pushJsonEx(data,"player",from.to_string());
  pushJsonEx(data,"black_amt",info.bet_black.to_string());
  pushJsonEx(data,"red_amt",info.bet_red.to_string());
  pushJsonEx(data,"strike_amt",info.bet_strike.to_string());
  std::string tx_id;
  get_transaction_tx(tx_id);
  pushJsonEx(data,"tx_id",tx_id,false);
  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    gameLog.id = getNewLogsIndex();
    gameLog.data = data;
  });
  print("222222222222222222");
  //find player
  auto player_index = _betInfo_table.get_index<name("byplayer")>();
  auto bet_itr = player_index.find(from.value);
  //find gameid
  while(bet_itr != player_index.end()){
    if(bet_itr->game_id == info.game_id ){
      break;
    }
    bet_itr++;
  }
  if (bet_itr == player_index.end()) {
    _betInfo_table.emplace(get_self(), [&](auto& bet) {
      bet.id = _betInfo_table.available_primary_key();
      bet.player = from;
      bet.game_id = info.game_id;
      bet.seq.push_back(info.seq);
      bet.black_amt.push_back(info.bet_black);
      bet.red_amt.push_back(info.bet_red);
      bet.strike_amt.push_back(info.bet_strike);
      bet.created_at = get_current_time();
      bet.tx_id.push_back(get_transaction_tx());
      bet.svr_id.push_back(info.svr_id);
      bet.state = betState::BS_BETTING;
    });
  }else{
    player_index.modify(bet_itr,get_self(), [&](auto& bet) {
      bet.seq.push_back(info.seq);
      bet.black_amt.push_back(info.bet_black);
      bet.red_amt.push_back(info.bet_red);
      bet.strike_amt.push_back(info.bet_strike);
      bet.created_at = get_current_time();
      bet.tx_id.push_back(get_transaction_tx());
      bet.svr_id.push_back(info.svr_id);
    });
  }

  print("3333333333333333333");
  auto accountItr = _accounts_table.require_find(from.value,"please deposit first!");
  _accounts_table.modify(accountItr,get_self(), [&](auto& account) {
    account.balance -= quantity;
  });
  eosio::check(accountItr->balance.amount >= 0, "not enough balance");

  print("44444444444444444");
  bet_action act{ get_self(), {get_self(), "active"_n}};
  act.send(info.game_id,from,info.seq,quantity,info.bet_black,info.bet_red,info.bet_strike,accountItr->balance,info.sign,info.svr_id);
}

ACTION zjh::beton(name from,eosio::asset quantity, string memo){
  require_auth(get_self());
  betonFunc(from, quantity, memo);
}

void zjh::on_deposit(name from, name to, eosio::asset quantity, std::string memo)
{
  require_auth(from);
  // eosio::check(get_self() == to, "wrong deposit");
  if(get_self() != to){
    return;
  }
  //现在这样 无法存eos了
  if (memo.find("deposit") == 0){
    std::vector<std::string_view> infos = splitSV(memo, "|");
    if(infos.size() != 2){
      return;
    }
    depositFunc(name(infos[1]), quantity);
  }
  // betonFunc(from, quantity, memo);
}

template<name::raw TableName, typename T>
void clearTable(multi_index<TableName,T> &table){
  auto g_itr = table.begin();
  while (g_itr != table.end()) {
    g_itr = table.erase(g_itr);
  }
}

ACTION zjh::clearalltable() {
  require_auth(get_self());
  clearTable(_globalState_table);
  clearTable(_gameStatus_table);
  clearTable(_gameLog_table);
  clearTable(_gameLog2_table);
  clearTable(_accounts_table);
  auto g_itr = _betInfo_table.begin();
  while (g_itr != _betInfo_table.end()) {
    g_itr = _betInfo_table.erase(g_itr);
  }
}

ACTION zjh::startbet(uint64_t block_index, string sign,string public_key){
  require_auth(get_self());
  auto gameid = 0;
  asset zero;
  zero.symbol = symbol(USE_SYMBOL,4);
  string data;
  data += "{";
  pushJsonEx(data,"event_id","gameStart");
  _gameStatus_table.emplace(get_self(), [&](auto& gameStatus) {
    gameStatus.id = _gameStatus_table.available_primary_key();
    gameStatus.block_index = block_index;
    gameStatus.sign = sign;
    gameStatus.public_key = public_key;
    gameStatus.state = gameState::BETTING;
    gameStatus.created_at = get_current_time();
    gameStatus.stop_at = (current_time_point() + seconds(getTimeStop())).sec_since_epoch();
    gameStatus.bet_black  = zero;
    gameStatus.bet_red    = zero;
    gameStatus.bet_strike = zero;
    gameStatus.sys_balance =  getUserBalance(get_self());
    gameStatus.start_txid = get_transaction_tx();
    
    setCurentGameId(gameStatus.id);
    pushJson(data,"game_id",gameStatus.id);
    pushJson(data,"state",gameState::BETTING);
    pushJson(data,"stop_at",gameStatus.stop_at);
  });
  
  pushJson(data,"block_index",block_index);
  pushJsonEx(data,"sign",sign);
  std::string tx_id;
  get_transaction_tx(tx_id);
  pushJsonEx(data,"start_txid",tx_id);

  //find global setting
  pushJson(data,"cur_max_bet",getCurMaxBet());
  pushJson(data,"strike_cur_max_bet",getStrikeCurMaxBet(),false);

  //清空之前的log
  clearLogs();
  clearLogs2();
  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    gameLog.id = getNewLogsIndex();
    gameLog.data = data;
  });

  //最多保存记录
  deleteOldGameStatus();
}

void zjh::setCurentGameId(int64_t value){
  setValueWithKey(KEY_CUR_GAME,value);
}

auto zjh::getCurentGame(){
  auto gameId = getValueWithkey(KEY_CUR_GAME,0);
  auto game_itr = _gameStatus_table.find(gameId);
  eosio::check(game_itr != _gameStatus_table.end(),"no current game");
  return game_itr;
}

void zjh::stopbet(){
  require_auth(get_self());
  //find first game in betting
  auto game_itr = getCurentGame();
  eosio::check(game_itr->state==gameState::BETTING, "game not in betting");

  //stop the game
  _gameStatus_table.modify(game_itr,get_self(), [&](auto& gameStatus) {
    gameStatus.state = gameState::STOP;
    gameStatus.stop_at = get_current_time();
  });
  string data;
  data += "{";
  pushJsonEx(data,"event_id","gameStop");
  pushJson(data,"game_id",game_itr->id);
  pushJson(data,"state",gameState::STOP,false);
  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    gameLog.id = getNewLogsIndex();
    gameLog.data = data;
  });

  //find bets in this game
  auto game_index = _betInfo_table.get_index<name("bygameid")>();
  auto bet_itr = game_index.find(game_itr->id);
  while(bet_itr != game_index.end()){
    game_index.modify(bet_itr,get_self(), [&](auto& bet) {
      bet.state = betState::WAIT_SETTLEMENT;
    });
    bet_itr++;
  }
}

ACTION zjh::opencards(string sign,string seed,uint64_t block_index,string block_hash){
  require_auth(get_self());
  size_t begin = 0;

  //get last 32 char
  if(block_hash.size() >= 32)
    begin = block_hash.size() - 32;
  string baseStr = seed + block_hash.substr(begin,32);
  
  //get card hex
  checksum256 wash_hash = eosio::sha256(baseStr.c_str(), baseStr.size());
  auto dataArray = wash_hash.extract_as_byte_array();

  //log
  string data;
  data += "{";
  pushJsonEx(data,"event_id","gameResult");

  auto game_itr = getCurentGame();
  eosio::check(game_itr->state==gameState::STOP, "game not stop betting");
  _gameStatus_table.modify(game_itr,get_self(), [&](auto& game) {
    toHex(dataArray.data(),dataArray.size(),game.wash_hash);
    analyzeCard(game);
    game.reveal_at = get_current_time();
    game.block_index = block_index;
    game.block_hash = block_hash;
    game.seed = seed;
    game.state = gameState::SHOWING;
    game.open_txid = get_transaction_tx();

    pushJson(data,"game_id",game.id);
    pushJson(data,"state",game.state);
    pushJsonEx(data,"wash_hash",game.wash_hash);
    pushJson(data,"winner",game.winner);
    pushJson(data,"win_card_type",game.win_card_type);
    pushJsonEx(data,"black_card",game.black_card);
    pushJsonEx(data,"red_card",game.red_card,false);

    record_action act{ get_self(), {get_self(), "active"_n}};
    act.send(game.black_card,game.red_card,game.winner,game.win_card_type,game.reveal_at,game.created_at,game.id,game.state);
  });

  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    gameLog.id = getNewLogsIndex();
    gameLog.data = data;
  });

  settelmentNext(0);
}

void zjh::settelmentNext(uint32_t count)
{
  eosio::transaction txn{};
  txn.actions.emplace_back(
      eosio::permission_level(get_self(), "active"_n),
      get_self(),
      "settlement"_n,
      std::make_tuple(5,count + 1));
  txn.delay_sec = 1;
  txn.send(5, get_self());

  // settlement_action act{ get_self(), {get_self(), "active"_n}};
  // act.send(5,count + 1);
}

ACTION zjh::settlement(uint32_t dispose_count,uint32_t count){
  require_auth(get_self());

  //find bets in this game
  auto state_index = _betInfo_table.get_index<name("bystate")>();
  auto bet_itr = state_index.find(betState::WAIT_SETTLEMENT);

  auto num = 0;
  string data;
  uint64_t settlementId = bet_itr->game_id;  //正在结算的gameid
  auto curGame_itr = getCurentGame();
  auto game_itr = _gameStatus_table.find(settlementId);
  string winners;
  string memo;
  std::vector<uint64_t> finishGame;
  reveal_each_action act{ get_self(), {get_self(), "active"_n}};

  while (bet_itr != state_index.end() && bet_itr->state == betState::WAIT_SETTLEMENT  && num<dispose_count) {
    num++;
    if(settlementId != bet_itr->game_id){
      //开始新一个局号的结算了，说明上一局结算完成
      finishGame.push_back(settlementId);
      settlementId = bet_itr->game_id;
      game_itr = _gameStatus_table.find(settlementId);
    }
    if(game_itr != _gameStatus_table.end()){
      if(!isInSettlement(game_itr->state)){
        continue;
      }
      if(game_itr->winner != WIN_BLACK && game_itr->winner != WIN_RED){
        //流局 结算
        _gameStatus_table.modify(game_itr,get_self(), [&](auto& gameStatus) {
          gameStatus.state = gameState::DRAW;
        });
      }

      asset zero;
      zero.symbol = symbol(USE_SYMBOL,4);
      asset winCount = zero;
      asset winCount_black = zero;
      asset winCount_red = zero;
      asset winCount_strike = zero;
      asset totalWinCount = zero;
      asset total_black_amt = zero;
      asset total_red_amt = zero;
      asset total_strike_amt = zero;
      asset valid_amt = zero;
      asset valid_temp = zero;
      string valid_playtype;
      string valid_svrid;

      auto accountItr = _accounts_table.require_find(bet_itr->player.value,"please deposit first2!");

      //先计算出总下注,valid
      for(int i=0; i<bet_itr->black_amt.size(); i++){
        total_black_amt += bet_itr->black_amt[i];
        total_red_amt += bet_itr->red_amt[i];
        total_strike_amt += bet_itr->strike_amt[i];
      }
      valid_amt = total_red_amt - total_black_amt;
      if (valid_amt.amount < 0){
        valid_amt.amount = 0 - valid_amt.amount;
      }
      valid_temp = valid_amt;

      bool firstBet = true;
      for(int i=0; i<bet_itr->black_amt.size(); i++){      
        if(game_itr->state == gameState::DRAW){
          //流局返还
          winCount_black = bet_itr->black_amt[i];
          winCount_red = bet_itr->red_amt[i];
          winCount_strike = bet_itr->strike_amt[i];
          winCount = winCount_black + winCount_red + winCount_strike;
          memo = "draw";
        }else{
          switch(game_itr->winner){
            case WIN_BLACK:
            winCount_black = bet_itr->black_amt[i] * winRate[game_itr->winner-1] / 100;
            winCount = winCount_black;
            break;
            case WIN_RED:
            winCount_red = bet_itr->red_amt[i] * winRate[game_itr->winner-1] / 100;
            winCount = winCount_red;
            break;
          }
          winCount_strike = bet_itr->strike_amt[i] * strikeRate[game_itr->win_card_type -1];
          winCount += winCount_strike;
          memo = "you win";
          totalWinCount += winCount;
        }

        // if(winCount_black.amount > 0){
                
          act.send(bet_itr->player, bet_itr->tx_id[i],"龙",bet_itr->black_amt[i],winCount_black,valid_temp,bet_itr->svr_id[i]);
          if(firstBet){
            firstBet = false;
            valid_temp = zero;
          }
        // }
        // if(winCount_red.amount > 0){
          // reveal_each_action act{ get_self(), {get_self(), "active"_n}};
          act.send(bet_itr->player,bet_itr->tx_id[i],"凤",bet_itr->red_amt[i],winCount_red,valid_temp,bet_itr->svr_id[i]);
          if(firstBet){
            firstBet = false;
            valid_temp = zero;
          }
        // }
        // if(winCount_strike.amount > 0){
          // reveal_each_action act{ get_self(), {get_self(), "active"_n}};
          act.send(bet_itr->player,bet_itr->tx_id[i],"幸运一击",bet_itr->red_amt[i],winCount_strike,valid_temp,bet_itr->svr_id[i]);
          if(firstBet){
            firstBet = false;
            valid_temp = zero;
          }
        // }            
               
        if(winCount.amount > 0){
            _accounts_table.modify(accountItr,get_self(), [&](auto& account) {
              account.balance += winCount;
            });
        }
      }      

      reveal_action act{ get_self(), {get_self(), "active"_n}};
        act.send(game_itr->black_pork,game_itr->red_pork,game_itr->winner,game_itr->win_card_type,game_itr->reveal_at,game_itr->id,game_itr->seed,game_itr->sign,game_itr->public_key,game_itr->block_index,game_itr->block_hash,bet_itr->player,4294967295,total_black_amt,total_red_amt,total_strike_amt,totalWinCount,accountItr->balance,valid_amt,valid_svrid);
      
      // if(game_itr->id == settlementId && winCount.amount > 0){
      //   //是当前的局，打log
      //   if(winners.size()!=0){
      //     winners += "|";
      //   }
      //   winners += bet_itr->player.to_string();
      //   winners += "-";
      //   winners += winCount.to_string();
      // }      
    }

    //erase betInfo
    bet_itr = state_index.erase(bet_itr);
  }

  if (num == 0){
    //无下注,这里不考虑延迟的情况。
    settlementId = curGame_itr->id;
  }

  // if(curGame_itr->id == settlementId && winners != ""){
  //   //是当前的局，打log
    // data = "{";
    // pushJsonEx(data,"event_id","gameSettlement");
    // pushJson(data,"game_id",game_itr->id);
    // pushJson(data,"state",gameState::SETTLEMENT);
    // pushJsonEx(data,"winners",winners,false);

    // _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    //   gameLog.id = getNewLogsIndex();
    //   gameLog.data = data;
    // });
  // }

  // if(bet_itr == state_index.end() && isInSettlement(curGame_itr->state)){
  //   //finish,这里不考虑延迟的情况
  //   finishGame.push_back(curGame_itr->id);
  //   data = "{";
  //   pushJsonEx(data,"event_id","gameSettlementFinish");
  //   pushJson(data,"game_id",curGame_itr->id);
  //   pushJson(data,"state",gameState::FINISH,false);

  //   //删除之前的
  //   clearLogs2();
  //   _gameLog2_table.emplace(get_self(), [&](auto& gameLog) {
  //     gameLog.id = getNewLogsIndex2();
  //     gameLog.data = data;
  //   });
  // }

  for (auto it = finishGame.begin();it != finishGame.end();it++){  
    //更改gamestatus
    auto gameItr = _gameStatus_table.find(*it);
    if(gameItr == _gameStatus_table.end()){
      continue;
    }
    if(gameItr->state == gameState::DRAW){
      continue;
    }
    _gameStatus_table.modify(gameItr,get_self(), [&](auto& gameStatus) {
      gameStatus.state = gameState::FINISH;
    });
  }

  if (bet_itr != state_index.end()){
    settelmentNext(count);
  }
}

void zjh::depositFunc(name from,eosio::asset quantity){
  eosio::check(quantity.amount >= 0, "cant deposit minus");
  // auto hash = std::hash<std::string_view>()(from);
  auto hash = from.value;
  auto accountItr = _accounts_table.find(hash);
  eosio::asset balance;
  if (accountItr == _accounts_table.end()) {
    _accounts_table.emplace(get_self(), [&](auto& account) {
      account.playerid = from;
      account.player = from.to_string();
      account.balance = quantity;
      balance = account.balance;
    });
  } else {
    // Modify a message record if it exists
    _accounts_table.modify(accountItr, get_self(), [&](auto& account) {
      account.balance += quantity;
      balance = account.balance;
    });
  }
  depositrecord_action act{ get_self(), {get_self(), "active"_n}};
  act.send(from, quantity, balance);
}

void zjh::deposit(name from,eosio::asset quantity){
  require_auth(get_self());
  depositFunc(from, quantity);
}

void zjh::withdraw(name from,eosio::asset quantity){
  require_auth(get_self());
  eosio::check(quantity.amount >= 0, "cant withdraw minus");
  auto accountItr = _accounts_table.require_find(from.value,"please deposit first!");
  _accounts_table.modify(accountItr,get_self(), [&](auto& account) {
    account.balance -= quantity;
    eosio::check(account.balance.amount >= 0, "not enough balance left");
  });
  action{
    permission_level{get_self(), "active"_n},
    "eosio.token"_n,
    "transfer"_n,
    std::make_tuple(get_self(), from, quantity,"提款")
  }.send();
}

void zjh::clearLogs(){
    auto log_itr = _gameLog_table.begin();
    while (log_itr != _gameLog_table.end()) {
      log_itr = _gameLog_table.erase(log_itr);
    }
}
void zjh::clearLogs2(){
    auto log2_itr = _gameLog2_table.begin();
    while (log2_itr != _gameLog2_table.end()) {
      log2_itr = _gameLog2_table.erase(log2_itr);
    }
}

bool zjh::isInSettlement(int32_t state){
  return state == gameState::SETTLEMENT || state == gameState::SHOWING || state == gameState::DRAW;
}

ACTION zjh::cancelgame(){
  //取消所有的进行中的游戏
  auto game_itr = _gameStatus_table.begin();
  while(game_itr != _gameStatus_table.end()){
    if (game_itr->state != gameState::FINISH && game_itr->state != gameState::SETTLEMENT){
      //stop the game
      _gameStatus_table.modify(game_itr,get_self(), [&](auto& gameStatus) {
        gameStatus.state = gameState::DRAW;
      });      
    }
    game_itr++;
  }
}

ACTION zjh::setstate(string key,int64_t value){
  require_auth(get_self());
  setValueWithKey(key,value);
}
ACTION zjh::delstate(string key){
  require_auth(get_self());
  auto keyValue = name(key).value;
  auto state_itr = _globalState_table.find(keyValue);
  if (state_itr != _globalState_table.end()) {
    _globalState_table.erase(state_itr);
  }
}

int64_t zjh::getValueWithkey(string key,int64_t defaultValue){
  auto keyValue = name(key).value;
  auto msg_itr = _globalState_table.find(keyValue);
  if (msg_itr != _globalState_table.end()) {
    return msg_itr->value;
  }else{
    return defaultValue;   //default value
  }
}

void zjh::setValueWithKey(string key,int64_t value){
  auto keyValue = name(key).value;
  auto state_itr = _globalState_table.find(keyValue);
  if (state_itr == _globalState_table.end()) {
    _globalState_table.emplace(get_self(), [&](auto& state) {
      state.key = keyValue;
      state.value = value;
    });
  }else{
    _globalState_table.modify(state_itr,get_self(), [&](auto& state) {
      state.value = value;
    });
  }
}

int64_t zjh::getCurMaxBet(){
  return getValueWithkey(KEY_CUR_MAX_BET, 2000000);
}

int64_t zjh::getStrikeCurMaxBet(){
  return getValueWithkey(KEY_STRIKE_CUR_MAX_BET, 500000);
}

int64_t zjh::getTimeStop(){
  return getValueWithkey(KEY_TIME_STOP, 25);
}

int64_t zjh::getSizeGames(){
  return getValueWithkey(KEY_SIZE_GAMES, 100);
}

int64_t zjh::getNewLogsIndex(){
  auto index = getValueWithkey(KEY_CUR_LOGS_INDEX,0);
  index++;
  setValueWithKey(KEY_CUR_LOGS_INDEX,index);
  return index;
}

int64_t zjh::getNewLogsIndex2(){
  auto index = getValueWithkey(KEY_CUR_LOGS_INDEX2,0);
  index++;
  setValueWithKey(KEY_CUR_LOGS_INDEX2,index);
  return index;
}

void zjh::deleteOldGameStatus(){
  //get count
  auto count = 0;
  auto it = _gameStatus_table.begin();
  while (it != _gameStatus_table.end()) {
    count++;
    it++;
  }
  it = _gameStatus_table.begin();
  count = count - getSizeGames();
  for(int i=0; i<count;i++){
    it = _gameStatus_table.erase(it);
  }
}
