#include <eosio/eosio.hpp>
#include <eosio/asset.hpp>

using namespace std;
using namespace eosio;

#define USE_SYMBOL             "EOS"
#define KEY_TIME_STOP          "timestop"
#define KEY_TIME_GAME          "timegame"
#define KEY_CUR_MAX_BET        "curmaxbet"
#define KEY_STRIKE_CUR_MAX_BET "stcurmaxbet"
#define KEY_SIZE_GAMES         "sizegames"
#define KEY_CUR_GAME           "curgame"
#define KEY_CUR_LOGS_INDEX     "logsindex"
#define KEY_CUR_LOGS_INDEX2    "logsindex2"
#define KEY_SERVER_ID          "serverid"
#define WIN_BLACK              1
#define WIN_RED                2

struct betInfo {
    std::string_view    action;
    uint64_t            game_id;
    name                player;
    asset               bet_amount;
    asset               bet_black;
    asset               bet_red;
    asset               bet_strike;
    std::string_view    sign;
    uint32_t            seq;
    string              svr_id;
};

//-------------------------------------------------
typedef std::vector<uint8_t> QP_Cards;
//specialA -> A会特殊处理成功0x0e
inline uint8_t getCardValue(uint8_t card, bool specialA = true)
{
	uint8_t value = card % 16;
	if (value == 1 && specialA) {
		//A -> 14
		value = 0x0E;
	}
	return value;
}

inline uint8_t getCardColor(uint8_t card)
{
	return card / 16;
}

inline bool comparisonValue(uint8_t card1, uint8_t card2)
{
	uint8_t cbValue1 = getCardValue(card1);
	uint8_t cbValue2 = getCardValue(card2);
	uint8_t cbFlower1 = getCardColor(card1);
	uint8_t cbFlower2 = getCardColor(card2);

	if (cbValue1 != cbValue2)
	{
		return cbValue1 > cbValue2;
	}
	else
	{
		return cbFlower1 > cbFlower2;
	}
}

//大->小
inline void sortCardList(QP_Cards& cardList)
{
	std::sort(cardList.begin(), cardList.end(), comparisonValue);
}
//--------------------------------------------------------
namespace zjhLogic{
#define	MAX_USER_CARD_COUNT			3								//最大扑克数量

	typedef std::array<uint8_t,3> ZJH_Cards;

	enum emCardType
	{
		CARD_TYPE_DANZHANG  = 1,		//单张
    CARD_TYPE_DUIZI_MIN = 2,		//对子2-8
		CARD_TYPE_DUIZI_BIG = 3,		//对子9-A
		CARD_TYPE_SHUNZI    = 4,		//顺子
		CARD_TYPE_JINHUA    = 5,		//金花
		CARD_TYPE_SHUNJIN   = 6,		//顺金
		CARD_TYPE_BAOZI     = 7, 		//豹子
	};

	//是否同花
	bool isSameFlower(QP_Cards& cards);
	//是否顺子
	bool IsSunZi(ZJH_Cards& cards);
	//是否豹子
	bool isBaoZi(ZJH_Cards& cards);
	//是否对子
	bool isDuiZi(ZJH_Cards& cards);

	//需要重新排列
	void resort(QP_Cards& cardList);
	//cardList=color+value  cards=value
	emCardType getCardType(QP_Cards& cardList, ZJH_Cards& cards);
	//大->小 对子单张 小顺子32A
	void sortCardListEx(QP_Cards& cardList);
	//true left > right
	bool compareCard(QP_Cards left, emCardType &lType, QP_Cards right, emCardType &rType);
}

CONTRACT zjh : public contract {
  public:
    using contract::contract;
    zjh(name receiver, name code, datastream<const char*> ds);

    ACTION clearalltable();
    ACTION startbet(uint64_t block_index, string sign,string public_key);
    ACTION stopbet();
    ACTION opencards(string sign,string seed,uint64_t block_index,string block_hash);
    ACTION settlement(uint32_t dispose_count,uint32_t count);
    ACTION cancelgame();
    ACTION beton(name from,eosio::asset quantity, string memo);
    ACTION deposit(name from,eosio::asset quantity);
    ACTION withdraw(name from,eosio::asset quantity);

    ACTION depositrecord(name from,eosio::asset quantity,eosio::asset balance){
      require_auth(get_self());
    }
    ACTION bet(uint64_t game_id,name player,uint32_t seq,asset bet_amount,asset bet_black,asset bet_red,asset bet_strike,asset balance,string sign,string svrid){
      require_auth(get_self());
    }
    ACTION record(string black_card,string red_card,uint32_t winner,uint32_t win_card_type,uint32_t reveal_at,uint32_t created_at,uint64_t game_id,uint32_t state){
      require_auth(get_self());
    }
    ACTION revealeach(name player,checksum256 txid,string playtype,asset amt,asset payout,asset valid,string svrid){
      require_auth(get_self());
    }
    ACTION reveal(string black_card,string red_card,uint32_t winner,uint32_t win_card_type,uint32_t reveal_at,uint64_t game_id,string seed,string seed_sign,string public_key,uint64_t block_id,string block_hash,name player,uint32_t seq,asset black_amt,asset red_amt,asset strike_amt,asset payout,asset balance,asset valid,string svrid){
      require_auth(get_self());
    }
    ACTION checkline(){
      require_auth(get_self());
    };
    using settlement_action = eosio::action_wrapper<"settlement"_n, &zjh::settlement>;

    using depositrecord_action = eosio::action_wrapper<"depositrecord"_n, &zjh::depositrecord>;
    using bet_action = eosio::action_wrapper<"bet"_n, &zjh::bet>;
    using record_action = eosio::action_wrapper<"record"_n, &zjh::record>;
    using reveal_each_action = eosio::action_wrapper<"revealeach"_n, &zjh::revealeach>;
    using reveal_action = eosio::action_wrapper<"reveal"_n, &zjh::reveal>;

    ACTION setstate(string key,int64_t value);
    ACTION delstate(string key);

    [[eosio::on_notify("eosio.token::transfer")]] 
    void on_deposit(name from, name to, eosio::asset quantity, std::string memo);

  private:
    enum gameState{
      PAUSE       = -1,
      BETTING     = 1,
      STOP        = 2,
      SHOWING     = 3,
      SETTLEMENT  = 4,
      FINISH      = 5,
      DRAW        = 6
    };

    enum betState{
      BS_BETTING        = 1,
      WAIT_SETTLEMENT   = 2,
      BS_FINISH         = 3
    };

    TABLE globalState {
      uint64_t  key;
      int32_t value;
      auto primary_key() const { return key; }
    };
    typedef multi_index<name("globalstate"), globalState> globalState_table;

    TABLE gameStatus {
      uint64_t    id;     //pk自增
      string      sign;   //种子签名
      string      public_key;
      int32_t     state;  //游戏状态 -1暂停 1开始下注 2停止下注 3开牌中 4结算中 5结算完成
      string      black_card;       //龙家牌显示 17|1|57|2(牌型)
      string      red_card;         //凤家牌显示
      string      black_pork;       //龙家牌显示 37[♥5],19[♣3],18[♣2],散牌
      string      red_pork;         //凤家牌显示
      uint32_t    winner;           //龙1 凤2
      uint32_t    win_card_type;
      uint32_t    reveal_at;        //开牌时间
      uint32_t    created_at;
      uint32_t    stop_at;          //停止下注时间
      uint64_t    block_index;
      string      block_hash;
      string      seed;
      string      wash_hash;
      asset       bet_black;
      asset       bet_red;
      asset       bet_strike;
      asset       sys_balance;
      checksum256 start_txid;
      checksum256 open_txid;

      auto primary_key() const { return id; }
      // int32_t get_state() const { return state; }
    };
    typedef multi_index<name("gamestatus"), gameStatus
    // ,indexed_by<"bystate"_n, const_mem_fun<gameStatus, int32_t, &gameStatus::get_state>>
    > gameStatus_table;

    TABLE accounts {
      name        playerid;
      string      player;
      asset       balance;
      uint64_t    lastgmdode;
      auto primary_key() const { return playerid.value; }
    };
    typedef multi_index<name("accounts"), accounts> accounts_table;

    TABLE bets {
      uint64_t    id;        //pk自增
      name        player;
      uint64_t    game_id;   //gameStatus.id
      vector<uint32_t>    seq;       //确定那笔下注用
      vector<asset>       black_amt;  
      vector<asset>       red_amt;
      vector<asset>       strike_amt;
      vector<checksum256> tx_id;
      vector<string> svr_id;
      uint32_t    created_at;
      uint32_t    state;
      auto primary_key() const { return id; }
      uint64_t get_player() const { return player.value; }
      uint64_t get_gameid() const { return game_id; }
      uint64_t get_state() const { return state; }
    };
    // typedef multi_index<name("bets"), bets> betInfo_table;
    typedef multi_index<name("bets"), bets
    ,indexed_by<"byplayer"_n, const_mem_fun<bets, uint64_t, &bets::get_player>>
    ,indexed_by<"bygameid"_n, const_mem_fun<bets, uint64_t, &bets::get_gameid>>
    ,indexed_by<"bystate"_n, const_mem_fun<bets, uint64_t, &bets::get_state>>
    > betInfo_table;

    TABLE gameLog {
      uint64_t    id;     //pk自增
      string      data;
      auto primary_key() const { return id; }
    };
    typedef multi_index<name("logs"), gameLog> gameLog_table;
    typedef multi_index<name("logs2"), gameLog> gameLog2_table;

    bool analyzeMemo(std::string memo, betInfo& info,asset& total);
    // void getCardType(string_view);
    //
    void getCardStr(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType);
    void getCardStrPork(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType);
    void analyzeCard(gameStatus& game);
    int64_t getValueWithkey(string key,int64_t defaultValue);
    void    setValueWithKey(string key,int64_t value);
    int64_t getCurMaxBet();
    int64_t getStrikeCurMaxBet();
    int64_t getTimeStop();
    // int64_t getTimeGame();
    int64_t getSizeGames();
    auto    getCurentGame();
    void    setCurentGameId(int64_t value);
    int64_t getNewLogsIndex();
    int64_t getNewLogsIndex2();
    void    deleteOldGameStatus();
    void    betonFunc(name from,eosio::asset quantity, string &memo);
    void    depositFunc(name from,eosio::asset quantity);
    void    settelmentNext(uint32_t count);

    void    clearLogs();
    void    clearLogs2();
    bool    isInSettlement(int32_t state);

    globalState_table _globalState_table;
    gameStatus_table  _gameStatus_table;
    betInfo_table     _betInfo_table;
    gameLog_table     _gameLog_table;
    gameLog2_table    _gameLog2_table;
    accounts_table    _accounts_table;
    const float winRate[2] = {195,195};  //balck-1.95 red-1.95
    const uint8_t strikeRate[7] = {0,0,2,3,3,12,25};  //单张-对子小-对子大-顺子-金花-顺金-豹子
    const string typeStr[7] = {
      "散牌","对子2-8","对子9-A","顺子","金花","顺金","豹子"
    };
};
