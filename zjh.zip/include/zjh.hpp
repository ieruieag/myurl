#include <eosio/eosio.hpp>
#include <eosio/asset.hpp>

using namespace std;
using namespace eosio;

#define KEY_TIME_STOP          "time_stop"
#define KEY_TIME_GAME          "time_game"
#define KEY_CUR_MAX_BET        "cur_max_bet"
#define KEY_STRIKE_CUR_MAX_BET "strike_cur_max_bet"
#define KEY_SIZE_GAMES         "strike_cur_max_bet"
#define KEY_CUR_GAME           "cur_game"
#define WIN_BLACK              1
#define WIN_RED                2

struct betInfo {
    std::string_view    action;
    uint64_t            game_id;
    name                player;
    asset               bet_amount;
    asset               bet_black;
    asset               bet_red;
    asset               bet_strike;
    std::string_view    sign;
};

//-------------------------------------------------
typedef std::vector<uint8_t> QP_Cards;
//specialA -> A会特殊处理成功0x0e
inline uint8_t getCardValue(uint8_t card, bool specialA = true)
{
	uint8_t value = card % 16;
	if (value == 1 && specialA) {
		//A -> 14
		value = 0x0E;
	}
	return value;
}

inline uint8_t getCardColor(uint8_t card)
{
	return card / 16;
}

inline bool comparisonValue(uint8_t card1, uint8_t card2)
{
	uint8_t cbValue1 = getCardValue(card1);
	uint8_t cbValue2 = getCardValue(card2);
	uint8_t cbFlower1 = getCardColor(card1);
	uint8_t cbFlower2 = getCardColor(card2);

	if (cbValue1 != cbValue2)
	{
		return cbValue1 > cbValue2;
	}
	else
	{
		return cbFlower1 > cbFlower2;
	}
}

//大->小
inline void sortCardList(QP_Cards& cardList)
{
	std::sort(cardList.begin(), cardList.end(), comparisonValue);
}
//--------------------------------------------------------
namespace zjhLogic{
#define	MAX_USER_CARD_COUNT			3								//最大扑克数量

	typedef std::array<uint8_t,3> ZJH_Cards;

	enum emCardType
	{
		CARD_TYPE_DANZHANG = 1,		//单张
		CARD_TYPE_DUIZI    = 2,		//对子
		CARD_TYPE_SHUNZI   = 3,		//顺子
		CARD_TYPE_JINHUA   = 4,		//金花
		CARD_TYPE_SHUNJIN  = 5,		//顺金
		CARD_TYPE_BAOZI    = 6		//豹子
	};

	//是否同花
	bool isSameFlower(QP_Cards& cards);
	//是否顺子
	bool IsSunZi(ZJH_Cards& cards);
	//是否豹子
	bool isBaoZi(ZJH_Cards& cards);
	//是否对子
	bool isDuiZi(ZJH_Cards& cards);

	//需要重新排列
	void resort(QP_Cards& cardList);
	//cardList=color+value  cards=value
	emCardType getCardType(QP_Cards& cardList, ZJH_Cards& cards);
	//大->小 对子单张 小顺子32A
	void sortCardListEx(QP_Cards& cardList);
	//true left > right
	bool compareCard(QP_Cards &left, emCardType &lType, QP_Cards &right, emCardType &rType);
}

CONTRACT zjh : public contract {
  public:
    using contract::contract;
    zjh(name receiver, name code, datastream<const char*> ds);

    ACTION startbet(uint64_t block_index, string sign);
    ACTION stopbet();
    ACTION opencards(string sign,string seed,uint64_t block_index,string block_hash);
    ACTION settlement(uint32_t dispose_count,uint32_t count);

    ACTION setstate(string key,int32_t value);
    ACTION delstate(string key);

    [[eosio::on_notify("eosio.token::transfer")]] 
    void deposit(name from, name to, eosio::asset quantity, std::string memo);

  private:
    enum gameState{
      PAUSE       = -1,
      BETTING     = 1,
      STOP        = 2,
      SHOWING     = 3,
      SETTLEMENT  = 4,
      FINISH      = 5
    };

    enum betState{
      BS_BETTING        = 1,
      WAIT_SETTLEMENT   = 2,
      BS_FINISH         = 3
    };

    TABLE globalState {
      uint64_t  key;
      int32_t value;
      auto primary_key() const { return key; }
    };
    typedef multi_index<name("globalstate"), globalState> globalState_table;

    TABLE gameStatus {
      uint64_t    id;     //pk自增
      string      sign;   //种子签名
      int32_t     state;  //游戏状态 -1暂停 1开始下注 2停止下注 3开牌中 4结算中 5结算完成
      string      black_card;       //龙家牌显示 17|1|57|2(牌型)
      string      red_card;         //凤家牌显示
      uint32_t    winner;           //龙1 凤2
      uint32_t    win_card_type;
      uint32_t    reveal_at;
      uint32_t    created_at;
      uint32_t    stop_at;
      uint64_t    block_index;
      string      block_hash;
      string      seed;
      string      wash_hash;
      asset       bet_black;
      asset       bet_red;
      asset       bet_strike;
      asset       sys_balance;
      auto primary_key() const { return id; }
    };
    typedef multi_index<name("gamestatus"), gameStatus> gameStatus_table;

    TABLE bets {
      uint64_t    id;        //pk自增
      name        player;
      uint64_t    game_id;   //gameStatus.id
      asset       black_amt;  
      asset       red_amt;   
      asset       strike_amt;
      uint32_t    created_at;
      checksum256 tx_id;
      uint32_t    state;
      auto primary_key() const { return id; }
    };
    typedef multi_index<name("bets"), bets> betInfo_table;

    TABLE gameLog {
      uint64_t    id;     //pk自增
      string      data;
      auto primary_key() const { return id; }
    };
    typedef multi_index<name("logs"), gameLog> gameLog_table;

    void analyzeMemo(std::string_view memo, betInfo& info,asset& total);
    // void getCardType(string_view);
    void getCardStr(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType);
    void analyzeCard(gameStatus& game);
    int32_t getValueWithkey(string key,int32_t defaultValue);
    void    setValueWithKey(string key,int32_t value);
    int32_t getCurMaxBet();
    int32_t getStrikeCurMaxBet();
    int32_t getTimeStop();
    int32_t getTimeGame();
    int32_t getSizeGames();
    auto    getCurentGame();
    void    setCurentGameId(int32_t value);

    globalState_table _globalState_table;
    gameStatus_table  _gameStatus_table;
    betInfo_table     _betInfo_table;
    gameLog_table     _gameLog_table;
};
