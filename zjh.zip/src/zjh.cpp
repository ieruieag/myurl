#include <zjh.hpp>
#include <eosio/system.hpp>
#include <string>
#include <eosio/transaction.hpp>
#include <eosio/crypto.hpp>

template <typename T>
void pushJson(string& ret, std::string_view key, T value,bool bNotLast = true) {
	ret += "\"";
	ret += key;
	ret += "\":";
	ret += std::to_string(value);
	if (bNotLast) {
		ret += ",";
	}
	else {
		ret += "}";
	}
}
void pushJsonEx(string& ret, std::string_view key, std::string_view value, bool bNotLast = true) {
	ret += "\"";
	ret += key;
	ret += "\":\"";
	ret += value;
	ret += "\"";
	if (bNotLast) {
		ret += ",";
	}
	else {
		ret += "}";
	}
}

//返回的是int,但不会有负数
int64_t floatStrToInt(std::string num) {
    num.erase(std::remove(num.begin(), num.end(), '.'), num.end());
    int64_t ret = std::strtoll(num.c_str(),NULL,10);
    eosio::check(ret >= 0, "bet cant be minus");
    return ret;
}

//----------------analyze card------------
bool isValid(std::string_view hash, int begin) {
    return 0 < begin && begin < hash.size();
}

uint8_t getCard(std::string_view hash, size_t& begin) {
    if (!isValid(hash, begin))
        return -1;
    uint8_t numCard = -1;
    uint8_t numColor = -1;
    char c = '0';
    do
    {
        //card
        c = hash[begin];
        numCard = std::strtol(&c, NULL, 16);
        begin--;
        if (numCard < 1 || numCard > 0xE) {
            continue;
        }
        if (!isValid(hash, begin))
            break;
        //color
        c = hash[begin];
        numColor = std::strtol(&c, NULL, 16) % 4;
        begin--;
        break;
    } while (isValid(hash, begin));
    return numCard + numColor * 16;
}

void getMultiCard(std::string_view hash, size_t& begin, QP_Cards& allCard,size_t num) {
    uint8_t oneCard;
    do
    {
        oneCard = getCard(hash, begin);
        auto it = std::find(allCard.begin(), allCard.end(), oneCard);
        if (it != allCard.end()) {
            continue;
        }
        allCard.push_back(oneCard);

    } while (allCard.size() < num && isValid(hash, begin));
}
//---------------------------------------------

std::vector<std::string_view>
splitSV(std::string_view strv, std::string_view delims = " ")
{
    std::vector<std::string_view> output;
    size_t first = 0;

    while (first < strv.size())
    {
        const auto second = strv.find_first_of(delims, first);
        if (first != second)
            output.emplace_back(strv.substr(first, second - first));

        if (second == std::string_view::npos)
            break;

        first = second + 1;
    }
    return output;
}

checksum256 get_transaction_tx() {
   auto size = transaction_size();
   char buf[size];
   uint32_t read = read_transaction( buf, size );
   eosio::check( size == read, "read_transaction failed");
   return eosio::sha256(buf, read);
}

uint32_t get_current_time(){
  return current_time_point().sec_since_epoch();
}

void toHex(const void* data, uint32_t len, std::string& hexStr) {
    constexpr static uint32_t max_stack_buffer_size = 513;
    const char* hex_characters = "0123456789abcdef";

    uint32_t buffer_size = 2 * len + 1;
    if (buffer_size < len) return;

    void* buffer;
    if (max_stack_buffer_size < buffer_size) {
        buffer = malloc(buffer_size);
    }
    else {
        buffer = alloca(buffer_size);
    }
    memset(buffer, 0, buffer_size);
    
    char* b = reinterpret_cast<char*>(buffer);
    const uint8_t* d = reinterpret_cast<const uint8_t*>(data);
    for (uint32_t i = 0; i < len; ++i) {
        *b = hex_characters[d[i] >> 4];
        ++b;
        *b = hex_characters[d[i] & 0x0f];
        ++b;
    }

    hexStr = (char*)buffer;
    if (max_stack_buffer_size < buffer_size) {
        free(buffer);
    }
}

zjh::zjh(name receiver, name code, datastream<const char*> ds)
: contract(receiver, code, ds), 
  _globalState_table(receiver, receiver.value),
  _gameStatus_table(receiver, receiver.value),
  _betInfo_table(receiver, receiver.value),
  _gameLog_table(receiver, receiver.value)
{}

void zjh::analyzeMemo(std::string_view memo, betInfo& info,asset& total) {
    std::vector<std::string_view> infos = splitSV(memo, "|");
    //check
    eosio::check(infos.size() == 8, "memo not include 8 info");
    info.action     = infos[0];
    info.game_id    = std::stoll(infos[1].data());
    info.player     = name(infos[2]);
    info.bet_amount = asset(floatStrToInt(infos[3].data()),total.symbol);
    info.bet_black  = asset(floatStrToInt(infos[4].data()),total.symbol);
    info.bet_red    = asset(floatStrToInt(infos[5].data()),total.symbol);
    info.bet_strike = asset(floatStrToInt(infos[6].data()),total.symbol);
    info.sign = infos[7];

    eosio::check(total == info.bet_black + info.bet_red + info.bet_strike,
    "bet amount not match");
}

//------------------zjhlogic-----
bool zjhLogic::isSameFlower(QP_Cards& cards)
{
    uint8_t cbFlower = getCardColor(cards[0]);
    for (int i = 1; i < cards.size(); i++)
    {
        if (getCardColor(cards[i]) != cbFlower)
        {
            return false;
        }
    }
    return true;
}

bool zjhLogic::IsSunZi(ZJH_Cards& cards)
{
    //cardList必须是SortCardList(CardList)以后的，才能正确;
    if (cards[0] == 0x03 && cards[1] == 0x02 && cards[2] == 0x0E)
    {
		//32A
        return true;
    }
    if (cards[0] - cards[1] == 1 && cards[1] - cards[2] == 1)
    {
        return true;
    }
    return false;
}

bool zjhLogic::isBaoZi(ZJH_Cards& cards)
{
    //cardList必须是SortCardList(CardList)以后的，才能正确;
    if (cards[0] == cards[1] && cards[0] == cards[2])
    {
        return true;
    }
    return false;
}

bool zjhLogic::isDuiZi(ZJH_Cards& cards)
{
    //cardList必须是SortCardListEx以后的，才能正确;
	if (cards[0] == cards[1] && cards[1] != cards[2])
	{
		return true;
	}
	//SortCardListEx后没有ABB已经是BBA了
	return false;
}

void zjhLogic::resort(QP_Cards& cardList)
{
	uint8_t card1 = getCardValue(cardList[0]);
	uint8_t card2 = getCardValue(cardList[1]);
	uint8_t card3 = getCardValue(cardList[2]);

	if (card1 == 0x0e && card2 == 0x03 && card3 == 0x02)
	{
		//A32 -> 32A compareCard依赖
		uint8_t wDiffData = cardList[0];
		cardList[0] = cardList[1];
		cardList[1] = cardList[2];
		cardList[2] = wDiffData;
	}
	else if (card1 != card2 && card2 == card3)
	{
		//ABB -> BBA compareCard依赖
		uint8_t wDiffData = cardList[0];
		cardList[0] = cardList[2];
		cardList[2] = wDiffData;
	}
}

zjhLogic::emCardType zjhLogic::getCardType(QP_Cards& cardList, ZJH_Cards& cards)
{
	sortCardListEx(cardList);
	cards[0] = getCardValue(cardList[0]);
	cards[1] = getCardValue(cardList[1]);
	cards[2] = getCardValue(cardList[2]);

    //是否豹子
	if (isBaoZi(cards))
	{
		return CARD_TYPE_BAOZI;
	}
    bool isSameColor = isSameFlower(cardList);
    bool isSunZi = IsSunZi(cards);

    if (isSameColor && isSunZi) {
        return CARD_TYPE_SHUNJIN;
    }

	if (isSameColor) {
		return CARD_TYPE_JINHUA;
	}

    if (isSunZi) {
        return CARD_TYPE_SHUNZI;
    }

    if (isDuiZi(cards)) {
        return CARD_TYPE_DUIZI;
    }

    return CARD_TYPE_DANZHANG;
}

void zjhLogic::sortCardListEx(QP_Cards& cardList)
{
	sortCardList(cardList);
	resort(cardList);
}

//先获取type,在进行比较
bool zjhLogic::compareCard(QP_Cards& left, emCardType& lType, QP_Cards& right, emCardType& rType)
{
	ZJH_Cards cardsLeft;
	ZJH_Cards cardsRight;
	lType = getCardType(left, cardsLeft);
	rType = getCardType(right, cardsRight);
    //前提left和right都是从大到小排列的,依赖getCardType中的排序
	if (lType != rType)
	{
		return lType > rType;
	}
	for (int i = 0; i < MAX_USER_CARD_COUNT; i++)
	{
		if (cardsLeft[i] != cardsRight[i])
		{
			return cardsLeft[i] > cardsRight[i];
		}
	}

	//完全一样的，比对最大的牌的花色
    //例外32A-> 比3的花色   对子-> 比单张cards[2]的花色
	int num = 0;	//要比第几张牌的花色
	if (lType == CARD_TYPE_DUIZI) {
		//比单张cards[2]的花色
		num = 2;
	}
	return getCardColor(left[num]) > getCardColor(right[num]);
}
//-------------------------------
void zjh::getCardStr(std::string &cardStr,QP_Cards &cards,zjhLogic::emCardType cardType){
  for(int i=0; i<cards.size(); i++){
    cardStr += std::to_string(cards[i]);
    cardStr += "|";
  }
  cardStr += std::to_string(cardType);
}

void zjh::analyzeCard(gameStatus& game){
  //get card
  std::string_view hexStr = game.wash_hash;
  size_t begin = hexStr.size() - 1;
  QP_Cards black; 
  QP_Cards red;
  getMultiCard(hexStr, begin, black, 3);
  getMultiCard(hexStr, begin, red, 3);
  eosio::check(black.size() == 3,"can't get black card");
  eosio::check(red.size() == 3,"can't get red card");

  // zjhLogic::ZJH_Cards blackValue;
  // zjhLogic::ZJH_Cards redValue;
  zjhLogic::emCardType balckType;
  zjhLogic::emCardType redType;
  auto isBlackWin = zjhLogic::compareCard(black,balckType,red,redType);

  getCardStr(game.black_card,black,balckType);
  getCardStr(game.red_card,red,redType);
  if(isBlackWin){
    game.winner = WIN_BLACK;
    game.win_card_type = balckType;
  }else{
    game.winner = WIN_RED;
    game.win_card_type = redType;
  }
}

void zjh::deposit(name from, name to, eosio::asset quantity, std::string memo)
{
  require_auth(from);
  eosio::check(get_self() == to, "wrong deposit");

  betInfo info;
  analyzeMemo(memo,info,quantity);

  //check game is betting
  auto game_itr = _gameStatus_table.find(info.game_id);
  eosio::check(game_itr == _gameStatus_table.end(), "cant find this game");
  eosio::check(game_itr->state == gameState::BETTING, "game is not in betting");

  //check bet is valid
  eosio::check(quantity.amount <= getCurMaxBet(), "exceeded max bet");
  eosio::check(info.bet_strike.amount <= getStrikeCurMaxBet(), "exceeded max strike bet");

  _gameStatus_table.modify(game_itr,get_self(), [&](auto& game) {
    game.bet_black += info.bet_black;
    game.bet_red += info.bet_red;
    game.bet_strike += info.bet_strike;
  });

  //write log
  string data;
  data += "{";
  pushJsonEx(data,"event_id","newBet");
  pushJson(data,"game_id",info.game_id);
  pushJsonEx(data,"player",from.to_string());
  pushJsonEx(data,"black_amt",info.bet_black.to_string());
  pushJsonEx(data,"red_amt",info.bet_red.to_string());
  pushJsonEx(data,"strike_amt",info.bet_strike.to_string());
  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    gameLog.id = _gameLog_table.available_primary_key();
    gameLog.data = data;
  });

  _betInfo_table.emplace(get_self(), [&](auto& bet) {
    bet.id = _gameLog_table.available_primary_key();
    bet.player = from;
    bet.game_id = info.game_id;
    bet.black_amt = info.bet_black;
    bet.red_amt = info.bet_red;
    bet.strike_amt = info.bet_strike;
    bet.created_at = get_current_time();
    bet.tx_id = get_transaction_tx();
    bet.state = betState::BS_BETTING;
  });
}

ACTION zjh::startbet(uint64_t block_index, string sign){
  require_auth(get_self());

  string data;
  data += "{";
  pushJsonEx(data,"event_id","gameStart");
  _gameStatus_table.emplace(get_self(), [&](auto& gameStatus) {
    gameStatus.id = _gameStatus_table.available_primary_key();
    gameStatus.block_index = block_index;
    gameStatus.sign = sign;
    gameStatus.state = gameState::BETTING;
    gameStatus.created_at = get_current_time();
    // gameStatus.created_at = now().sec_since_epoch();
    pushJson(data,"game_id",gameStatus.id);
  });
  
  pushJson(data,"state",gameState::BETTING);
  pushJson(data,"stop_at",(current_time_point() + seconds(25)).sec_since_epoch());
  pushJson(data,"block_index",block_index);
  pushJsonEx(data,"sign",sign);

  //find global setting
  pushJson(data,"cur_max_bet",getCurMaxBet());
  pushJson(data,"strike_cur_max_bet",getStrikeCurMaxBet());
  
  //清空之前的log
  auto msg_itr = _gameLog_table.begin();
  while (msg_itr != _gameLog_table.end()) {
    msg_itr = _gameLog_table.erase(msg_itr);
  }
  _gameLog_table.emplace(get_self(), [&](auto& gameLog) {
    gameLog.id = _gameLog_table.available_primary_key();
    gameLog.data = data;
    setCurentGameId(gameLog.id);
  });
}

void zjh::setCurentGameId(int32_t value){
  setValueWithKey(KEY_CUR_GAME,value);
}

auto zjh::getCurentGame(){
  // eosio::check(_gameStatus_table.begin() != _gameStatus_table.end(),"no game start right now");
  //find first game in betting
  // auto game_itr = _gameStatus_table.find(11);
  // game_itr--;
  // while (game_itr != _gameStatus_table.rend()) {
  //   if(game_itr->state == gameState::BETTING){
  //     break;
  //   }
  // }
  // eosio::check(game_itr != _gameStatus_table.rend(),"no game start right now");
  auto gameId = getValueWithkey(KEY_CUR_GAME,0);
  return _gameStatus_table.get(gameId);
}

void zjh::stopbet(){
  //find first game in betting
  auto game_itr = _gameStatus_table.rbegin();
  // while (game_itr != _gameStatus_table.rend()) {
  //   if(game_itr->state == gameState::BETTING){
  //     break;
  //   }
  // }
  eosio::check(game_itr != _gameStatus_table.rend(),"no game need stop");
  eosio::check(game_itr->state==gameState::BETTING, "game not in betting");

  //stop the game
  _gameStatus_table.emplace(get_self(), [&](auto& gameStatus) {
    gameStatus.state = gameState::STOP;
    gameStatus.stop_at = get_current_time();
  });
}

ACTION zjh::opencards(string sign,string seed,uint64_t block_index,string block_hash){
  // auto game_itr = getCurentGameStatus();
  size_t begin = 0;

  //get last 32 char
  if(block_hash.size() >= 32)
    begin = block_hash.size() - 32;
  string data = seed + block_hash.substr(begin,32);

  //get card hex
  checksum256 wash_hash = eosio::sha256(data.c_str(), data.size());
  auto dataArray = wash_hash.extract_as_byte_array();
  std::string hexStr;
  

  auto game_itr = getCurentGame();
  _gameStatus_table.modify(game_itr,get_self(), [&](auto& game) {
    toHex(dataArray.data(),dataArray.size(),game.wash_hash);
    analyzeCard(game);
    game.reveal_at = get_current_time();
    
    game.block_index = block_index;
    game.block_hash = block_hash;
  });
}

ACTION zjh::settlement(uint32_t dispose_count,uint32_t count){
  auto num = 0;
  auto bet_itr = _betInfo_table.begin();
  auto game = getCurentGame();
  asset winCount;
  while (bet_itr != _betInfo_table.end() && num<dispose_count) {
    num++;
    switch(game.winner){
      case WIN_BLACK:
      winCount = game.bet_black;
      break;
      case WIN_RED:
      winCount = game.bet_red;
      break;
    }
    _betInfo_table.erase(bet_itr);
  }
}

ACTION zjh::setstate(string key,int32_t value){
  require_auth(get_self());
  setValueWithKey(key,value);
}
ACTION zjh::delstate(string key){
  require_auth(get_self());
  auto keyValue = name(key).value;
  auto state_itr = _globalState_table.find(keyValue);
  if (state_itr != _globalState_table.end()) {
    _globalState_table.erase(state_itr);
  }
}

int32_t zjh::getValueWithkey(string key,int32_t defaultValue){
  auto keyValue = name(key).value;
  auto msg_itr = _globalState_table.find(keyValue);
  if (msg_itr == _globalState_table.end()) {
    return msg_itr->value;
  }else{
    return defaultValue;   //default value
  }
}

void zjh::setValueWithKey(string key,int32_t value){
  auto keyValue = name(key).value;
  auto state_itr = _globalState_table.find(keyValue);
  if (state_itr == _globalState_table.end()) {
    _globalState_table.emplace(get_self(), [&](auto& state) {
      state.key = keyValue;
      state.value = value;
    });
  }else{
    _globalState_table.modify(state_itr,get_self(), [&](auto& state) {
      state.value = value;
    });
  }
}

int32_t zjh::getCurMaxBet(){
  return getValueWithkey(KEY_CUR_MAX_BET, 2000000);
}

int32_t zjh::getStrikeCurMaxBet(){
  return getValueWithkey(KEY_STRIKE_CUR_MAX_BET, 500000);
}
